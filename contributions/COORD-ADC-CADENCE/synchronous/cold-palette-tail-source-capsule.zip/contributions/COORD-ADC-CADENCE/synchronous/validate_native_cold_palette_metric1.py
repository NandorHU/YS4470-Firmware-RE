"""Execute HEAP+18 palette/tag4d and native metric1/tag49 growth schedules."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_padding14_properties import Padding14Replay, PADDING14_RETURN, METRIC12_VECTOR, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE, vector_bytes
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

PALETTE_METRIC_RETURN=0x80058E04


class PaletteMetric1Replay(Padding14Replay):
    def __init__(self,raw):
        self.palette_metric_phase=False
        self.palette18_calls,self.metric1_calls,self.metric1_results=[],[],[]
        self.palette_metric_input=None
        self.palette_metric_buffers={}
        super().__init__(raw)
        self.u.mem_map(0x12010000,0x10000)

    def code(self,u,pc,size,data):
        if self.palette_metric_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x8003AE20:
                self.palette18_calls.append(u.reg_read(UC_ARM_REG_R0))
            if pc==0x8003DCE4:
                self.palette_metric_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,1]
                self.metric1_calls.append(args)
            if pc==0x800259AC:self.metric1_results.append(u.reg_read(UC_ARM_REG_R0))
            if any(lo<=pc<hi for lo,hi in ((PADDING14_RETURN,PALETTE_METRIC_RETURN),(0x8003AE20,0x8003AE58),
                    (0x8003DCE4,0x8003DD0C),(0x80025958,0x800259B0),(0x80025CA4,0x80025CD4))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.palette_metric_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0x18<=address and address+size<=HEAP+0x20:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.palette_metric_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_palette_metric1(self,schedule):
        assert len(schedule)==2
        self.run_padding14((True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50),(METRIC12_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers,self.color_pair_buffers,
                        self.metric2_buffers,self.metric24_buffers,self.padding14_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values=[10,0xFF,0x1200FFFF,0x1200E71C,2,1,0x12002104,20,20,20,20,11,11]
        tags=[0x0B,0x21,0x20,0x30,0x32,0x34,0x55,0x12,0x13,0x10,0x11,0x14,0x15]
        pointer,summary,start=0x1200F000,0x2F,PADDING14_RETURN
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.padding14_phase=False
        self.palette_metric_phase=True
        steps=[]
        for index,(tag,success,return_pc,target) in enumerate(zip(
                (0x4D,0x49),schedule,(0x80058DE8,PALETTE_METRIC_RETURN),(0x12010100,0x12011000))):
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            if index==0:
                assert self.palette18_calls==[18]
                style,color,retained=self.palette_metric_input
                palette=struct.unpack('<H',self.u.mem_read(self.word(0x8003AE58)+18*2,2))[0]
                assert style==HEAP+0x18 and color==palette==0x9CF3 and retained>>16==0x1200
                value=palette|(retained&0xFFFF0000)
            else:
                assert self.metric1_calls==[[DISPLAY,1]] and self.metric1_results==[1]
                assert 130*1+80<320
                value=1
            size=6*(len(values)+1)
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,size,0x8003DE90]
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(pointer,len(values)*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*size
            self.u.mem_write(target-16,b'\x85'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\x58'*16)
            self.palette_metric_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);summary|=16;pointer=target
                self.palette_metric_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0x18,pointer,0x0B,summary,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc and self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.palette_metric_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x85'*16 and self.u.mem_read(a+len(expected),16)==b'\x58'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),raw_value=hex(value),actual_requested_bytes=size,
                              outcome_fixture='moving_success' if success else 'null',
                              style_hex=expected_heap[0x18:0x20].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(realloc_success_fixtures=list(schedule),steps=steps,native_metric1_result=1,
                    palette_wrapper_input=[hex(v) for v in self.palette_metric_input],
                    final_tags=[hex(t) for t in tags],final_values=[hex(v) for v in values],
                    final_style_hex=expected_heap[0x18:0x20].hex(),complete_heap_vectors_guards_checked=True,
                    all_prior_vectors_bss_data_display_timer_unchanged=True,caller_sp_preserved=True,
                    stop_pc=hex(PALETTE_METRIC_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=2):
            replay=PaletteMetric1Replay(raw);rows.append(replay.run_palette_metric1(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-palette-metric1.v1',images=images,total_cases=8,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_padding14_properties.py'))},
                limits=['Original palette18 lookup/tag4d wrapper gives raw12009cf3 with opaque incoming HIGH16; original25958(DISPLAY,1) takes minimum-result1 branch and inserts tag49 under all four null/moving-success schedules.',
                        'Each actual reallocpointer/size precedes explicit prefix-copy/poison-tail fixtures in new12010000 arena; all-success84/90-byte vectors and whole504-byte heap independently checked. All prior allocations/guards, BSS/DATA/display/timer and caller SP preserved.',
                        'Native allocator/freeing/reuse and raw palette/metric physical meaning remain unclaimed. No callbacks invoked; opaque payload limits persist.',
                        'Stops58e04 before HEAP+a0 style. Full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=8,metric1=1,success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

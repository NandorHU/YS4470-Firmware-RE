"""Verify HEAP+20 metric16 style and outcome-dependent opaque color payload."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_a8_style import A8StyleReplay, A8_RETURN, METRIC12_VECTOR, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE, vector_bytes, ALLOC, REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA
from validate_native_display_initializer_prefix import STATE

METRIC16_INLINE_RETURN=0x80058EF0
METRIC16_RETURN=0x80058F10


class Metric16StyleReplay(A8StyleReplay):
    def __init__(self,raw):
        self.metric16_style_phase=False
        self.metric16_calls,self.metric16_results,self.metric16_zero_calls=[],[],[]
        self.metric16_color_input=None
        self.metric16_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.metric16_style_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80032E14:
                self.metric16_zero_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)])
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,16]
                self.metric16_calls.append(args)
            if pc==0x800259AC:self.metric16_results.append(u.reg_read(UC_ARM_REG_R0))
            if pc==0x8003DC18:
                self.metric16_color_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if any(lo<=pc<hi for lo,hi in ((A8_RETURN,METRIC16_RETURN),(0x80058F70,0x80058F80),
                    (0x8005A334,0x8005A34C),(0x8003D828,0x8003D830),(0x8003DFA0,0x8003DFAC),
                    (0x8003DC68,0x8003DC74),(0x8003DC18,0x8003DC34),
                    (0x80025958,0x800259B0),(0x80025CA4,0x80025CD4))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.metric16_style_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0x20<=address and address+size<=HEAP+0x28:
                assert 0x80032E14<=pc<0x80032EA4 or pc in (0x8003DF78,0x8003DDF0,0x8003DDF4,
                    0x8003DF98,0x8003DF30,0x8003DF44,0x8003DE98,0x8003DED0)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.metric16_buffers.items()):
                assert pc in (0x8003DF4C,0x8003DF50,0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_metric16_style(self,schedule):
        assert len(schedule)==2
        self.run_a8_style((True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50),(METRIC12_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers,self.color_pair_buffers,
                        self.metric2_buffers,self.metric24_buffers,self.padding14_buffers,self.palette_metric_buffers,self.a0_buffers,self.a8_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.a8_phase=False
        self.metric16_style_phase=True
        self.stop=METRIC16_INLINE_RETURN
        self.u.emu_start(A8_RETURN,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==METRIC16_INLINE_RETURN and self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.metric16_zero_calls==[[HEAP+0x20,8,0x80058EC0]]
        value=(130*16+80)//160
        assert value==13 and self.metric16_calls==[[DISPLAY,16]] and self.metric16_results==[value]
        struct.pack_into('<IHBB',expected_heap,0x20,value,0x0B,1,1)
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        values,tags,pointer,start=[value],[0x0B],None,METRIC16_INLINE_RETURN
        steps=[]
        for index,(tag,success,return_pc) in enumerate(zip((0x21,0x20),schedule,(0x80058F00,METRIC16_RETURN))):
            count=len(values);api=ALLOC if count==1 else REALLOC;resume=0x8003DF24 if count==1 else 0x8003DE90
            size=6*(count+1)
            self.stop=api
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==api
            if index==0:value=0xFF
            else:
                style,color,retained=self.metric16_color_input
                expected_color=struct.unpack('<H',self.u.mem_read(STATE+8,2))[0]
                expected_high=0x1201 if schedule[0] else 0
                assert style==HEAP+0x20 and color==expected_color==0xE71C and retained>>16==expected_high
                value=expected_color|(expected_high<<16)
            if count==1:
                assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_LR)]==[12,resume]
            else:
                assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]==[pointer,size,resume]
                assert self.u.mem_read(pointer,count*6)==vector_bytes(values,tags)
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x12017000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success and count>1 else b'\xA5'*size
            self.u.mem_write(target-16,b'\x88'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\x89'*16)
            self.metric16_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);pointer=target
                self.metric16_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0x20,pointer,0x0B,5,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(resume,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc and self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.metric16_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x88'*16 and self.u.mem_read(a+len(expected),16)==b'\x89'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),raw_value=hex(value),actual_api=hex(api),actual_requested_bytes=size,
                              outcome_fixture='guarded_success' if success else 'null',
                              style_hex=expected_heap[0x20:0x28].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(allocation_success_fixtures=list(schedule),metric16_results=self.metric16_results,
                    color_wrapper_input=[hex(v) for v in self.metric16_color_input],steps=steps,
                    final_tags=[hex(t) for t in tags],final_values=[hex(v) for v in values],
                    final_style_hex=expected_heap[0x20:0x28].hex(),complete_heap_vectors_guards_checked=True,
                    all_prior_vectors_bss_data_display_timer_unchanged=True,caller_sp_preserved=True,
                    stop_pc=hex(METRIC16_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=2):
            replay=Metric16StyleReplay(raw);rows.append(replay.run_metric16_style(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-metric16-style.v1',images=images,total_cases=8,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_a8_style.py'))},
                limits=['Original HEAP+20 cold init and actual STATEbyte1 branch58f70 execute metric16/raw13 and tag0b inline. Tags21/rawff and20/STATE+8 lowe71c execute under all four null/guarded-success schedules.',
                        'Count1 native allocator32800/12 versus count>1 native realloc32ae4 exact arguments checked before modeled outcomes. Opaque color HIGH16 is1201 after previous guarded allocation success in newarena,0 after null; no physical-format meaning is inferred.',
                        'Each complete vector/504-byte heap and every old/newguard,BSS/DATA/display/timer and caller SP independently checked. Native allocator/free/reuse remain modeled fixtures.',
                        'Stops58f10 before flag branch/palette tail. Full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=8,metric16=rows[-1]['metric16_results'],success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

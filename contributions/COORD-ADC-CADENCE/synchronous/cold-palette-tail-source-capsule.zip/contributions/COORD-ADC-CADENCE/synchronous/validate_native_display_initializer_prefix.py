"""Execute cold display-registration initializer to its original configuration hook."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP
from validate_native_display_timer_registration import DisplayTimerReplay, AFTER_TIMER, TIMER, TIMER_LIST, TIMER_STATE, BASE, DRIVER, DISPLAY

GATE,STATE,OBJECT=0x805ABD84,0x805ABC6C,0x807B52F8
HEAP,HEAP_BYTES=0x11006000,0x1F8
CONFIG_HOOK=0x80058A34


class InitializerPrefixReplay(DisplayTimerReplay):
    def __init__(self,raw):
        self.initializer_phase=False
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.initializer_phase:
            if pc==0x80040658:
                args=[u.reg_read(reg) for reg in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3)]
                args.append(self.word(u.reg_read(UC_ARM_REG_SP)))
                assert args==[DISPLAY,self.palette5,self.palette0,0,0x80068B20]
                self.initializer_arguments.append(args)
            if pc==0x80032800:
                assert u.reg_read(UC_ARM_REG_R0)==HEAP_BYTES and u.reg_read(UC_ARM_REG_LR)==0x80040694
                self.initializer_heap_calls+=1
                u.reg_write(UC_ARM_REG_R0,HEAP);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
            if pc==0x80025CE4:
                assert u.reg_read(UC_ARM_REG_R0)==DISPLAY
                self.resolution_calls+=1
            if any(lo<=pc<hi for lo,hi in ((AFTER_TIMER,0x80025B60),(0x80025BFC,0x80025C30),
                    (0x8004073C,0x80040750),(0x80040658,0x8004072C),(0x8003AE20,0x8003AE58),
                    (0x80025C94,0x80025CA0),(0x80025CE4,0x80025D20))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex();return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.initializer_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if address==GATE:
                assert pc==0x80040694 and size==4 and value==HEAP
                return
            if STATE<=address and address+size<=STATE+20:
                assert 0x80040658<=pc<0x8004072C
                return
            if OBJECT<=address and address+size<=OBJECT+36:
                assert 0x800406D0<=pc<0x800406FC
                return
        super().write(u,access,address,size,value,data)

    def run_initializer_prefix(self):
        timer=self.run_timer(0,0)
        self.put(GATE,0)
        self.u.mem_write(STATE,b'\xA5'*20)
        self.u.mem_write(OBJECT-16,b'\xD5'*16)
        self.u.mem_write(OBJECT,b'\xA5'*36)
        self.u.mem_write(HEAP-16,b'\x6E'*16)
        self.u.mem_write(HEAP,b'\xA5'*HEAP_BYTES)
        self.u.mem_write(HEAP+HEAP_BYTES,b'\xE6'*16)
        table=self.word(0x8003AE58)
        self.palette0=struct.unpack('<H',self.u.mem_read(table,2))[0]
        self.palette5=struct.unpack('<H',self.u.mem_read(table+10,2))[0]
        before_display=bytearray(self.u.mem_read(DISPLAY,0x15C))
        before_driver=bytes(self.u.mem_read(DRIVER,80))
        before_timer=bytes(self.u.mem_read(TIMER,32))
        before_list=bytes(self.u.mem_read(TIMER_LIST,12))
        before_manager=bytes(self.u.mem_read(TIMER_STATE,0x14))
        self.timer_phase=False;self.initializer_phase=True
        self.initializer_arguments=[];self.initializer_heap_calls=self.resolution_calls=0
        self.stop=CONFIG_HOOK
        self.u.emu_start(AFTER_TIMER,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==CONFIG_HOOK
        assert self.u.reg_read(UC_ARM_REG_LR)==0x80040700
        assert self.initializer_heap_calls==1 and self.resolution_calls==2
        assert self.word(GATE)==HEAP
        expected_object=bytearray(b'\xA5'*36)
        struct.pack_into('<I',expected_object,0,self.word(0x80040738))
        struct.pack_into('<I',expected_object,0xC,DISPLAY)
        struct.pack_into('<HH',expected_object,0x10,self.palette5,self.palette0)
        struct.pack_into('<4I',expected_object,0x14,0x80068B20,0x80068B20,0x80068B20,0)
        assert bytes(self.u.mem_read(OBJECT,36))==expected_object
        expected_state=bytearray(b'\xA5'*20)
        expected_state[0]=0;expected_state[1]=1  # Original high-resolution branch (854 >=720).
        struct.pack_into('<I',expected_state,12,HEAP)
        assert bytes(self.u.mem_read(STATE,20))==expected_state
        before_display[0x29]=255;struct.pack_into('<H',before_display,0x2A,0xFFFF)
        assert bytes(self.u.mem_read(DISPLAY,0x15C))==before_display
        assert bytes(self.u.mem_read(DRIVER,80))==before_driver and self.word(DRIVER+0x1C)==0
        assert bytes(self.u.mem_read(TIMER,32))==before_timer
        assert bytes(self.u.mem_read(TIMER_LIST,12))==before_list
        assert bytes(self.u.mem_read(TIMER_STATE,0x14))==before_manager
        assert self.u.mem_read(OBJECT-16,16)==b'\xD5'*16
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        assert self.u.mem_read(HEAP,HEAP_BYTES)==b'\xA5'*HEAP_BYTES
        return dict(entry='0x80025ae8',registered_timer_callback=timer['registered_callback'],
                    initializer='0x80040658',actual_arguments=self.initializer_arguments[0],
                    palette_entry0=hex(self.palette0),palette_entry5=hex(self.palette5),raw_palette_table=hex(table),
                    gate_word=hex(GATE),allocated_state_bytes=HEAP_BYTES,gate_points_to=hex(self.word(GATE)),
                    object_pointer=hex(OBJECT),complete_object_hex=expected_object.hex(),state_hex=expected_state.hex(),
                    logical_resolution_queries=self.resolution_calls,state_byte0=0,state_byte1=1,
                    configuration_hook=hex(CONFIG_HOOK),allocated_payload_untouched=True,guards_unchanged=True,
                    driver_and_timer_unchanged=True,stop_pc=hex(CONFIG_HOOK))


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()
    manifest=json.loads(Path('original-firmware/manifest.json').read_bytes())
    images,originals,observed={},[],[]
    for item in manifest['images']:
        raw=Path(item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=InitializerPrefixReplay(raw)
        observed.append((replay.run_initializer_prefix(),replay.coverage))
    assert observed[0]==observed[1]
    case,coverage=observed[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in coverage.items())
    report=dict(schema='ys4470.native-display-initializer-prefix.v1',images=images,total_cases=2,cases=[case],
                instruction_bytes={hex(pc):word for pc,word in sorted(coverage.items())},
                source_sha256={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in (Path(__file__).name,'validate_native_display_timer_registration.py')},
                limits=['Original connected display/driver/timer registration takes actual zero-gate fallback, executes original palette lookups and initializer0x80040658 through native resolution queries/global/object stores to hook0x80058a34.',
                        'One504-byte heap allocation is modeled. Gate stores actual allocated pointer; complete36-byte object/20-byte state and display prefix changes match independent byte references initialized from explicit poisoned fixtures. Guards and prior timer/list/driver stay intact.',
                        'Raw palette values and static pointers come from original ROM literals/table. The object role/name and uninitialized retained bytes are not promoted beyond this prefix contract.',
                        'Stops before configuration hook; allocated504-byte payload is still poison, state byte0 remains0 and initializer has not returned. No complete initialization, root creation, callback firing, storage-format or physical LCD/timing claim.',
                        'Prior raw clock/list-manager/previous-pointer/hardware/context/display allocation fixtures persist.'])
    args.out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print('PASS 2 native cold registration initializer-prefix cases')


if __name__=='__main__':main()

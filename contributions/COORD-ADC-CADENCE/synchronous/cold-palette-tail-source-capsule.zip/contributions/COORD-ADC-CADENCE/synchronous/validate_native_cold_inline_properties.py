"""Execute first two inline native property stores without allocating."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP
from validate_native_cold_style_descriptors import DescriptorReplay, ATTACH, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA

AFTER_TWO = 0x80058B54


class InlineReplay(DescriptorReplay):
    def __init__(self, raw):
        self.inline_phase = False
        self.inline_calls, self.setter_calls = [], []
        super().__init__(raw)

    def code(self, u, pc, size, data):
        if self.inline_phase:
            if pc == self.stop:
                u.emu_stop()
                return
            assert pc not in (0x80032800,0x80032AE4,0x80032A80,0x80032A44), 'Unexpected allocator/free'
            if pc == ATTACH:
                self.inline_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)])
            if pc == 0x8003DDF0:
                self.setter_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3)])
            if any(lo <= pc < hi for lo,hi in ((ATTACH,0x8003E074),(0x8003DDE4,0x8003DFA0),
                                               (0x80058B44,AFTER_TWO))):
                assert size == 4
                self.coverage[pc] = bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.inline_phase and any(a <= address and address+size <= a+8 for a in (HEAP+0xD0,HEAP+0xD8)):
            assert u.reg_read(UC_ARM_REG_PC) in (0x8003DF78,0x8003DDF0,0x8003DDF4,0x8003DF98)
            return
        super().write(u,access,address,size,value,data)

    def run_inline(self):
        self.run_descriptors()
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32))}
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        for offset,record in zip((0xD0,0xD8),self.destinations):
            # One inline value, tag0x66, summary bit6, count1.
            struct.pack_into('<IHBB',expected_heap,offset,record,0x66,0x40,1)
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.descriptor_phase=False
        self.inline_phase=True
        self.stop=AFTER_TWO
        self.u.emu_start(ATTACH,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==AFTER_TWO
        assert self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.inline_calls==[[HEAP+0xD0,self.destinations[0],0x80058B44],
                                   [HEAP+0xD8,self.destinations[1],AFTER_TWO]]
        assert self.setter_calls==[[0x66,self.destinations[0],HEAP+0xD4,HEAP+0xD0],
                                  [0x66,self.destinations[1],HEAP+0xDC,HEAP+0xD8]]
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16
        assert self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected))==expected
        return dict(actual_property_tag='0x66',actual_summary_byte='0x40',inline_count=1,
                    property_tail='0x8003dde4',setter='0x8003ddf0',allocator_calls=0,
                    inline_calls=[[hex(v) for v in row] for row in self.inline_calls],
                    native_setter_arguments=[[hex(v) for v in row] for row in self.setter_calls],
                    first_inline_hex=expected_heap[0xD0:0xD8].hex(),second_inline_hex=expected_heap[0xD8:0xE0].hex(),
                    complete_heap_sha256=hashlib.sha256(expected_heap).hexdigest(),
                    complete_bss_data_display_timer_unchanged=True,guards_and_caller_sp_unchanged=True,
                    stop_pc=hex(AFTER_TWO),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=InlineReplay(raw);observations.append((replay.run_inline(),replay.coverage))
    assert observations[0]==observations[1]
    row,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-inline-properties.v1',images=images,total_cases=2,cases=[row],
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_style_descriptors.py'))},
                limits=['Actual0x8003e068 tail is0x8003dde4 with tag0x66, not previously anticipated0x80037f3c. Original cold count0 branch stores a single inline pointer and tag, count1 and category summary bit6; no allocator/free executes.',
                        'Both inline records and complete504-byte heap match independent byte references; whole BSS/DATA, previous descriptors, display/timer and guards remain unchanged; caller SP preserved.',
                        'Native descriptor callback pointers are only stored, never invoked. Initializer has not returned; later properties/root construction/registered refresh/physical timing remain open.',
                        'Prior hardware/heap/raw-clock/list-manager and cold DATA/BSS effect models remain explicit.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=2,inline_bytes=[row['first_inline_hex'],row['second_inline_hex']],stop=row['stop_pc'])))


if __name__=='__main__':main()

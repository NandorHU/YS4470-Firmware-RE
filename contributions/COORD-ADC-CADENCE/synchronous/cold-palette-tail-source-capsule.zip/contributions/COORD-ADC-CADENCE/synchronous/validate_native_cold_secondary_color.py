"""Verify tag55 secondary raw-color insertion and actual STATEbyte1 branch."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_base_style_outcomes import BaseStyleOutcomeReplay, BASE_VECTOR, BASE_RETURN, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA
from validate_native_display_initializer_prefix import STATE

SECONDARY_VECTOR=0x12001000
SECONDARY_WRAPPER=0x8003E004
COLOR_RETURN=0x80058C48
HIGH_BRANCH=0x80058F20


class SecondaryColorReplay(BaseStyleOutcomeReplay):
    def __init__(self,raw):
        self.secondary_phase=False
        self.secondary_input=None
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.secondary_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==SECONDARY_WRAPPER:
                self.secondary_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if any(lo<=pc<hi for lo,hi in ((BASE_RETURN,0x80058C54),(SECONDARY_WRAPPER,0x8003E020))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.secondary_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP<=address and address+size<=HEAP+8:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if SECONDARY_VECTOR<=address and address+size<=SECONDARY_VECTOR+18:
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_secondary(self,success):
        self.run_base_outcome(True)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (GROWTH-16,44),(MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        prior=bytes(self.u.mem_read(BASE_VECTOR,12))
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.secondary_phase=True
        self.stop=REALLOC
        self.u.emu_start(BASE_RETURN,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
        assert self.secondary_input is not None
        style,color,retained=self.secondary_input
        expected_color=struct.unpack('<H',self.u.mem_read(STATE+4,2))[0]
        assert style==HEAP and color==expected_color==0x2104
        payload=(color&0xFFFF)|(retained&0xFFFF0000)
        assert payload==0x12002104
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]==[BASE_VECTOR,18,0x8003DE90]
        assert self.u.reg_read(UC_ARM_REG_R8)==0x55 and self.u.reg_read(UC_ARM_REG_R9)==payload
        assert self.u.reg_read(UC_ARM_REG_SP)==sp-32
        initial=prior+b'\xA5'*6 if success else b'\xA5'*18
        self.u.mem_write(SECONDARY_VECTOR-16,b'\x7C'*16)
        self.u.mem_write(SECONDARY_VECTOR,initial)
        self.u.mem_write(SECONDARY_VECTOR+18,b'\xC7'*16)
        expected_vector=initial
        if success:
            expected_vector=struct.pack('<IIIHHH',0xFF,0x1100F7BE,payload,0x21,0x20,0x55)
            struct.pack_into('<IHBB',expected_heap,0,SECONDARY_VECTOR,0x21,0x24,3)
        self.u.reg_write(UC_ARM_REG_R0,SECONDARY_VECTOR if success else 0)
        self.stop=COLOR_RETURN
        self.u.emu_start(0x8003DE90,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==COLOR_RETURN
        assert self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.u.mem_read(STATE+1,1)==b'\1'
        self.stop=HIGH_BRANCH
        self.u.emu_start(COLOR_RETURN,0,count=100)
        assert self.u.reg_read(UC_ARM_REG_PC)==HIGH_BRANCH
        assert self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(SECONDARY_VECTOR,18)==expected_vector
        assert self.u.mem_read(SECONDARY_VECTOR-16,16)==b'\x7C'*16
        assert self.u.mem_read(SECONDARY_VECTOR+18,16)==b'\xC7'*16
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():assert self.u.mem_read(address,len(expected))==expected
        return dict(reallocator_outcome_fixture='moving_success' if success else 'null',
                    actual_old_pointer=hex(BASE_VECTOR),actual_requested_bytes=18,
                    secondary_input=[hex(v) for v in self.secondary_input],raw_payload=hex(payload),tag='0x55',
                    opaque_retained_high16=hex(retained>>16),style_hex=expected_heap[:8].hex(),
                    vector_hex=expected_vector.hex(),complete_heap_vector_references=True,
                    all_prior_vectors_bss_data_display_timer_guards_unchanged=True,caller_stack_preserved=True,
                    actual_state_byte1=1,actual_branch_target=hex(HIGH_BRANCH),stop_pc=hex(HIGH_BRANCH),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for success in (False,True):
            replay=SecondaryColorReplay(raw);rows.append(replay.run_secondary(success));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-secondary-color.v1',images=images,total_cases=4,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_base_style_outcomes.py'))},
                limits=['Original3e004 wrapper packs STATE+4 low2104 with opaque incomingR2 high1200, tag55. Actual old-pointer/new18-byte realloc arguments precede explicit null/moving-success prefix-copy fixtures.',
                        'Native continuation independently matches entire vector/504-byte heap and summary24/count3 on success; null leaves prior state unchanged. All old buffers/guards and BSS/DATA/display/timer references unchanged.',
                        'Original STATEbyte1==1 conditional actually branches58c48..58c50 to58f20, stopping before target body. Caller stack preserved; physical resolution/units/format are not inferred from raw payload.',
                        'Native allocator/freeing/reuse, remaining configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=4,payload='0x12002104',success_style=rows[1]['style_hex'],branch=rows[1]['actual_branch_target'])))


if __name__=='__main__':main()

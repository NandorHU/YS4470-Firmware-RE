"""Complete HEAP+18 metric2/tag32, raw1/tag34 and secondary-color/tag55."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_metric12_colors import Metric12ColorsReplay, COLOR_PAIR_RETURN, METRIC12_VECTOR, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE, vector_bytes
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA
from validate_native_display_initializer_prefix import STATE

METRIC2_RETURN=0x80058D40


class Metric2PropertiesReplay(Metric12ColorsReplay):
    def __init__(self,raw):
        self.metric2_phase=False
        self.metric2_calls,self.metric2_results=[],[]
        self.metric2_color_input=None
        self.metric2_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.metric2_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,2]
                self.metric2_calls.append(args)
            if pc==0x800259AC:self.metric2_results.append(u.reg_read(UC_ARM_REG_R0))
            if pc==0x8003E004:
                self.metric2_color_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if any(lo<=pc<hi for lo,hi in ((COLOR_PAIR_RETURN,METRIC2_RETURN),(0x80025958,0x800259B0),
                    (0x80025CA4,0x80025CD4),(0x8003DC90,0x8003DC9C),(0x8003DCA8,0x8003DCB4),
                    (0x8003E004,0x8003E020))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.metric2_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0x18<=address and address+size<=HEAP+0x20:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.metric2_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_metric2_properties(self,schedule):
        assert len(schedule)==3
        self.run_color_pair((True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50),(METRIC12_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers,self.color_pair_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values,tags=[10,0xFF,0x1200FFFF,0x1200E71C],[0x0B,0x21,0x20,0x30]
        pointer,summary,start=0x12006000,0x0D,COLOR_PAIR_RETURN
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.metric12_phase=False
        self.metric2_phase=True
        steps=[]
        for index,(tag,category_bit,success,return_pc) in enumerate(zip(
                (0x32,0x34,0x55),(8,8,32),schedule,(0x80058D20,0x80058D30,METRIC2_RETURN))):
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            assert self.metric2_calls==[[DISPLAY,2]] and self.metric2_results==[(130*2+80)//160]==[2]
            if index<2:value=(2,1)[index]
            else:
                style,color,retained=self.metric2_color_input
                expected_color=struct.unpack('<H',self.u.mem_read(STATE+4,2))[0]
                expected_high=0x1200 if schedule[1] else 0
                assert style==HEAP+0x18 and color==expected_color==0x2104 and retained>>16==expected_high
                value=expected_color|(expected_high<<16)
            size=6*(len(values)+1)
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,size,0x8003DE90]
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(pointer,len(values)*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x12007000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*size
            self.u.mem_write(target-16,b'\x82'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\x28'*16)
            self.metric2_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);summary|=category_bit;pointer=target
                self.metric2_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0x18,pointer,0x0B,summary,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc and self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.metric2_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x82'*16 and self.u.mem_read(a+len(expected),16)==b'\x28'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),raw_value=hex(value),actual_requested_bytes=size,
                              outcome_fixture='moving_success' if success else 'null',
                              style_hex=expected_heap[0x18:0x20].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(realloc_success_fixtures=list(schedule),steps=steps,native_metric_result=2,
                    final_tags=[hex(t) for t in tags],final_values=[hex(v) for v in values],
                    final_style_hex=expected_heap[0x18:0x20].hex(),complete_heap_vectors_guards_checked=True,
                    all_prior_vectors_bss_data_display_timer_unchanged=True,caller_sp_preserved=True,
                    stop_pc=hex(METRIC2_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=3):
            replay=Metric2PropertiesReplay(raw);rows.append(replay.run_metric2_properties(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-metric2-properties.v1',images=images,total_cases=16,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_metric12_colors.py'))},
                limits=['Original25958(DISPLAY,2) raw2, tag32/value2,tag34/raw1 and tag55/STATE+4 execute under all eight null/moving-success schedules. Every native realloc pointer/size precedes outcome modeling; all-success30/36/42 bytes.',
                        'Color opaque HIGH16 depends on immediately preceding realloc:1200 after success,0 after null. Independent whole values/tags/504-byte heap references reflect this without physical-format inference.',
                        'All retained old/new vectors, guards, whole BSS/DATA/display/timer and caller SP checked after every insertion. Native allocator/free/reuse not executed; no callbacks invoked.',
                        'Stops58d40 before subsequent STATE branch. Full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=16,metric_result=2,success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

"""Execute native metric5/tag1 insertion with null or guarded42-byte growth."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_compound_growth import CompoundReplay, CALLER_RETURN, vector_bytes, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

NEW = 0x1100C000
AFTER_TAG1 = 0x80058BE0


class Tag1Replay(CompoundReplay):
    def __init__(self,raw):
        self.tag1_phase=False
        self.metric5_calls,self.metric5_results=[],[]
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.tag1_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,5]
                self.metric5_calls.append(args)
            if pc==0x800259AC:
                self.metric5_results.append(u.reg_read(UC_ARM_REG_R0))
            if any(lo<=pc<hi for lo,hi in ((CALLER_RETURN,AFTER_TAG1),(0x80025958,0x800259B0),
                                           (0x80025CA4,0x80025CD4),(0x8003E074,0x8003E080))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.tag1_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+8<=address and address+size<=HEAP+16:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if NEW<=address and address+size<=NEW+42:
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_tag1(self,success):
        self.run_compound((True,True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (GROWTH-16,44),(MOVED-16,50))}
        for address,raw in self.compound_buffers.items():
            snapshots[address-16]=bytes(self.u.mem_read(address-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        sp=self.u.reg_read(UC_ARM_REG_SP)
        values,tags=[0x9CF3,0x7FFF,6,6,6,6],[0x20,0x0B,0x12,0x13,0x10,0x11]
        prior=vector_bytes(values,tags)
        old_pointer=0x1100B000
        assert self.u.mem_read(old_pointer,36)==prior
        self.reallocation_entry_phase=False  # Earlier helper allowed only argument7.
        self.tag1_phase=True
        self.stop=REALLOC
        self.u.emu_start(CALLER_RETURN,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
        assert self.metric5_calls==[[DISPLAY,5]]
        assert self.metric5_results==[(130*5+80)//160]==[4]
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]==[old_pointer,42,0x8003DE90]
        assert self.u.reg_read(UC_ARM_REG_R8)==1 and self.u.reg_read(UC_ARM_REG_R9)==4
        assert self.u.reg_read(UC_ARM_REG_SP)==sp-32
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        initial=prior+b'\xA5'*6 if success else b'\xA5'*42
        self.u.mem_write(NEW-16,b'\x79'*16)
        self.u.mem_write(NEW,initial)
        self.u.mem_write(NEW+42,b'\x97'*16)
        expected_new=initial
        if success:
            expected_new=vector_bytes(values+[4],tags+[1])
            struct.pack_into('<IHBB',expected_heap,8,NEW,0x20,7,7)
        self.u.reg_write(UC_ARM_REG_R0,NEW if success else 0)
        self.stop=AFTER_TAG1
        self.u.emu_start(0x8003DE90,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==AFTER_TAG1
        assert self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(NEW,42)==expected_new
        assert self.u.mem_read(NEW-16,16)==b'\x79'*16 and self.u.mem_read(NEW+42,16)==b'\x97'*16
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected))==expected
        return dict(native_metric_input=5,native_metric_result=4,tag='0x1',
                    actual_old_pointer=hex(old_pointer),actual_new_bytes=42,
                    reallocator_outcome_fixture='moving_success' if success else 'null',
                    prefix_copy_fixture_bytes=36 if success else 0,style_hex=expected_heap[8:16].hex(),
                    new_vector_hex=expected_new.hex(),complete_heap_and_vector_references=True,
                    old_buffers_bss_data_display_timer_guards_unchanged=True,caller_stack_restored=True,
                    stop_pc=hex(AFTER_TAG1),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for success in (False,True):
            replay=Tag1Replay(raw);rows.append(replay.run_tag1(success));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-tag1-growth.v1',images=images,total_cases=4,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_compound_growth.py'))},
                limits=['Original25958(DISPLAY,5) gives raw4 from encoded driver metric130; original3e074 inserts tag1. Actual count6 vector growth requests42 bytes before explicit null/moving-success outcome modeling.',
                        'Success prefix-copy36/poison-tail6 fixture permits original tag shift and value append; entire42-byte vector and504-byte heap independently checked. Null leaves prior style/vector unchanged.',
                        'All retained old allocations, guards, whole BSS/DATA/display/timer unchanged; caller stack restored at58be0. Native allocator/freeing/reuse and raw-value physical units are not claimed.',
                        'Remaining configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=4,native_metric_result=4,allocation_bytes=42,success_style=rows[1]['style_hex'])))


if __name__=='__main__':main()

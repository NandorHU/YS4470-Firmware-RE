"""Initialize HEAP+18 style, execute metric12, and check first growth outcomes."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_metric14_properties import Metric14Replay, METRIC14_RETURN, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_first_allocation import ALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

METRIC12_VECTOR=0x12004000
METRIC12_RETURN=0x80058CE4


class Metric12StyleReplay(Metric14Replay):
    def __init__(self,raw):
        self.metric12_phase=False
        self.metric12_calls,self.metric12_results,self.metric12_zero_calls=[],[],[]
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.metric12_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,12]
                self.metric12_calls.append(args)
            if pc==0x800259AC:self.metric12_results.append(u.reg_read(UC_ARM_REG_R0))
            if pc==0x80032E14:
                self.metric12_zero_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)])
            if any(lo<=pc<hi for lo,hi in ((METRIC14_RETURN,METRIC12_RETURN),(0x80025958,0x800259B0),
                    (0x80025CA4,0x80025CD4),(0x8005A334,0x8005A34C),(0x8003D828,0x8003D830),
                    (0x8003DC68,0x8003DC74),(0x8003DFA0,0x8003DFAC))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.metric12_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0x18<=address and address+size<=HEAP+0x20:
                assert 0x80032E14<=pc<0x80032EA4 or pc in (0x8003DF78,0x8003DDF0,0x8003DDF4,0x8003DF98,0x8003DF30,0x8003DF44)
                return
            if METRIC12_VECTOR<=address and address+size<=METRIC12_VECTOR+12:
                assert pc in (0x8003DF4C,0x8003DF50,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_metric12_style(self,success):
        self.run_metric14((True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.metric14_phase=False
        self.metric12_phase=True
        self.stop=ALLOC
        self.u.emu_start(METRIC14_RETURN,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==ALLOC
        value=(130*12+80)//160
        assert value==10 and self.metric12_calls==[[DISPLAY,12]] and self.metric12_results==[value]
        assert self.metric12_zero_calls==[[HEAP+0x18,8,0x80058CAC]]
        struct.pack_into('<IHBB',expected_heap,0x18,value,0x0B,1,1)
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_LR,UC_ARM_REG_R8,UC_ARM_REG_R9)]==[12,0x8003DF24,0x21,0xFF]
        assert self.u.reg_read(UC_ARM_REG_SP)==sp-32
        self.u.mem_write(METRIC12_VECTOR-16,b'\x7E'*16)
        self.u.mem_write(METRIC12_VECTOR,b'\xA5'*12)
        self.u.mem_write(METRIC12_VECTOR+12,b'\xE7'*16)
        expected_vector=b'\xA5'*12
        if success:
            expected_vector=struct.pack('<IIHH',value,0xFF,0x0B,0x21)
            struct.pack_into('<IHBB',expected_heap,0x18,METRIC12_VECTOR,0x0B,5,2)
        self.u.reg_write(UC_ARM_REG_R0,METRIC12_VECTOR if success else 0)
        self.stop=METRIC12_RETURN
        self.u.emu_start(0x8003DF24,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==METRIC12_RETURN and self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(METRIC12_VECTOR,12)==expected_vector
        assert self.u.mem_read(METRIC12_VECTOR-16,16)==b'\x7E'*16 and self.u.mem_read(METRIC12_VECTOR+12,16)==b'\xE7'*16
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():assert self.u.mem_read(address,len(expected))==expected
        return dict(native_metric_input=12,native_metric_result=value,style_offset='0x18',
                    first_inline_tag='0xb',next_tag='0x21',next_value='0xff',actual_allocation_bytes=12,
                    allocation_outcome_fixture='guarded_success' if success else 'null',
                    style_hex=expected_heap[0x18:0x20].hex(),vector_hex=expected_vector.hex(),
                    complete_heap_vector_references=True,all_old_vectors_bss_data_display_timer_guards_unchanged=True,
                    caller_stack_restored=True,stop_pc=hex(METRIC12_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for success in (False,True):
            replay=Metric12StyleReplay(raw);rows.append(replay.run_metric12_style(success));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-metric12-style.v1',images=images,total_cases=4,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_metric14_properties.py'))},
                limits=['Original cold HEAP+18 style init and actual STATEbyte1 metric12 selection execute. Native25958(DISPLAY,12) raw10 independently matches encoded130 arithmetic; first tag0b/value10 is inline.',
                        'Next tag21/rawff requests12-byte allocation before explicit null/guarded-success outcome modeling. Complete vector/504-byte heap, all prior vectors/guards, BSS/DATA/display/timer and caller SP independently checked through58ce4.',
                        'Raw values are not assigned physical units. Native allocator/freeing/reuse remain fixtures; opaque color payload high16 limit persists.',
                        'Remaining configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=4,native_metric_result=10,success_style=rows[1]['style_hex'],stop=rows[1]['stop_pc'])))


if __name__=='__main__':main()

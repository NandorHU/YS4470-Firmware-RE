"""Execute two native20-byte descriptor constructors in the cold hook caller."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP
from validate_native_cold_style_zero import ColdStyleReplay, CONSTRUCTOR, HEAP, HEAP_BYTES, STATE, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA

ATTACH = 0x8003E068


class DescriptorReplay(ColdStyleReplay):
    def __init__(self, raw):
        self.descriptor_phase = False
        self.descriptor_calls, self.descriptor_zero_calls = [], []
        super().__init__(raw)
        self.destinations = [self.word(0x800599F4), self.word(0x800599F8)]
        assert all(BSS <= a and a+20 <= BSS+LENGTH for a in self.destinations)
        assert abs(self.destinations[0]-self.destinations[1]) >= 20

    def code(self, u, pc, size, data):
        if self.descriptor_phase:
            if pc == self.stop:
                u.emu_stop()
                return
            if pc == CONSTRUCTOR:
                sp = u.reg_read(UC_ARM_REG_SP)
                args = [u.reg_read(r) for r in (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3)]
                args.extend([self.word(sp), self.word(sp+4)])
                self.descriptor_calls.append(args)
            if pc == 0x80032E14:
                args = [u.reg_read(r) for r in (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_LR)]
                assert args[0] in self.destinations and args[1:] == [20, 0x8003E0A4]
                self.descriptor_zero_calls.append(args)
            if any(lo <= pc < hi for lo, hi in ((CONSTRUCTOR, 0x8003E0C0),
                                               (0x80058B18, 0x80058B54))):
                assert size == 4
                self.coverage[pc] = bytes(u.mem_read(pc, size)).hex()
                return
        super().code(u, pc, size, data)

    def write(self, u, access, address, size, value, data):
        if self.descriptor_phase and any(a <= address and address+size <= a+20 for a in self.destinations):
            pc = u.reg_read(UC_ARM_REG_PC)
            assert CONSTRUCTOR <= pc < 0x8003E0C0 or 0x80032E14 <= pc < 0x80032EA4
            return
        super().write(u, access, address, size, value, data)

    def run_descriptors(self):
        self.run_style_zero()
        snapshots = {a: bytes(self.u.mem_read(a,n)) for a,n in
                     ((DATA,0x15E4),(HEAP-16,HEAP_BYTES+32),(DISPLAY,0x15C),(TIMER,32))}
        expected_bss = bytearray(self.u.mem_read(BSS,LENGTH))
        sp = self.u.reg_read(UC_ARM_REG_SP)
        font, callback = self.word(0x800599F0), self.word(0x800599EC)
        expected_calls = [[self.destinations[0],font,callback,0x50,0x46,0],
                          [self.destinations[1],font,callback,0x50,0,0]]
        records = []
        for dst,arg1,arg2,arg3,arg4,arg5 in expected_calls:
            record = struct.pack('<5I',arg1,arg5,arg2,arg3,arg4)
            expected_bss[dst-BSS:dst-BSS+20] = record
            records.append(dict(destination=hex(dst),words=[hex(v) for v in struct.unpack('<5I',record)]))
        self.style_phase = False  # Do not reuse the earlier8-byte-zero admission hook.
        self.descriptor_phase = True
        self.stop = ATTACH
        self.u.emu_start(CONSTRUCTOR,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC) == ATTACH
        assert self.u.reg_read(UC_ARM_REG_SP) == sp
        assert self.descriptor_calls == expected_calls
        assert len(self.descriptor_zero_calls) == 2
        assert self.u.mem_read(BSS,LENGTH) == expected_bss
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected)) == expected
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)] == [HEAP+0xD0,self.destinations[0],0x80058B44]
        return dict(records=records,native_calls=[[hex(v) for v in row] for row in self.descriptor_calls],
                    native_zero_calls=[[hex(a),n,hex(lr)] for a,n,lr in self.descriptor_zero_calls],
                    complete_bss_reference=True,data_heap_display_timer_unchanged=True,caller_sp_preserved=True,
                    pending_attachment=[hex(HEAP+0xD0),hex(self.destinations[0])],
                    pending_return='0x80058b44',stop_pc=hex(ATTACH),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=DescriptorReplay(raw);observations.append((replay.run_descriptors(),replay.coverage))
    assert observations[0]==observations[1]
    row,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-style-descriptors.v1',images=images,total_cases=2,cases=[row],
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_style_zero.py'))},
                limits=['Two original20-byte constructors execute actual memzero, argument shuffling and stores. Each complete descriptor independently matches five raw input words.',
                        'Entire8,058,888-byte BSS reference changes only the two records; complete DATA,504-byte heap with guards, display/timer and caller SP remain unchanged.',
                        'Stops before first attachment0x8003e068; initializer not returned. Raw descriptor roles/units are not promoted beyond actual arguments, and no callback is invoked.',
                        'Prior cold DATA/BSS effect and hardware/heap/raw-clock/list-manager models persist; no physical timing or full GUI initialization claim.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=2,records=row['records'],next=row['pending_attachment'])))


if __name__=='__main__':main()

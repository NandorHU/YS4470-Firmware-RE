"""Execute actual metric24 branch and all four compound property outcomes."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_metric2_properties import Metric2PropertiesReplay, METRIC2_RETURN, METRIC12_VECTOR, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE, vector_bytes
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

METRIC24_RETURN=0x80058D70


class Metric24CompoundReplay(Metric2PropertiesReplay):
    def __init__(self,raw):
        self.metric24_phase=False
        self.metric24_calls,self.metric24_results=[],[]
        self.metric24_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.metric24_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,24]
                self.metric24_calls.append(args)
            if pc==0x800259AC:self.metric24_results.append(u.reg_read(UC_ARM_REG_R0))
            if any(lo<=pc<hi for lo,hi in ((METRIC2_RETURN,METRIC24_RETURN),(0x80058F40,0x80058F50),
                    (0x80025958,0x800259B0),(0x80025CA4,0x80025CD4),(0x8003DD64,0x8003DDE4))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.metric24_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0x18<=address and address+size<=HEAP+0x20:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.metric24_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_metric24(self,schedule):
        assert len(schedule)==4
        self.run_metric2_properties((True,True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50),(METRIC12_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers,self.color_pair_buffers,self.metric2_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values,tags=[10,0xFF,0x1200FFFF,0x1200E71C,2,1,0x12002104],[0x0B,0x21,0x20,0x30,0x32,0x34,0x55]
        pointer,summary,start=0x12009000,0x2D,METRIC2_RETURN
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.metric2_phase=False
        self.metric24_phase=True
        steps=[]
        for index,(tag,success,return_pc) in enumerate(zip(
                (0x12,0x13,0x10,0x11),schedule,(0x8003DD74,0x8003DD80,0x8003DD8C,METRIC24_RETURN))):
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            value=(130*24+80)//160
            assert value==20 and self.metric24_calls==[[DISPLAY,24]] and self.metric24_results==[value]
            size=6*(len(values)+1)
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,size,0x8003DE90]
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(pointer,len(values)*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x1200A000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*size
            self.u.mem_write(target-16,b'\x83'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\x38'*16)
            self.metric24_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);summary|=2;pointer=target
                self.metric24_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0x18,pointer,0x0B,summary,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc
            assert self.u.reg_read(UC_ARM_REG_SP)==(sp-16 if index<3 else sp)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.metric24_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x83'*16 and self.u.mem_read(a+len(expected),16)==b'\x38'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),raw_value=value,actual_requested_bytes=size,
                              outcome_fixture='moving_success' if success else 'null',
                              style_hex=expected_heap[0x18:0x20].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(realloc_success_fixtures=list(schedule),steps=steps,native_metric_result=20,
                    final_tags=[hex(t) for t in tags],final_values=[hex(v) for v in values],
                    final_style_hex=expected_heap[0x18:0x20].hex(),complete_heap_vectors_guards_checked=True,
                    all_prior_vectors_bss_data_display_timer_unchanged=True,compound_frame_restored_bytes=16,
                    stop_pc=hex(METRIC24_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=4):
            replay=Metric24CompoundReplay(raw);rows.append(replay.run_metric24(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-metric24-compound.v1',images=images,total_cases=32,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_metric2_properties.py'))},
                limits=['Actual STATEbyte1==1 branch58f40 executes native25958(DISPLAY,24), raw20, and compound tags12/13/10/11 under all sixteen null/moving-success realloc schedules.',
                        'Each actual pointer/size checked before explicit prefix-copy/poison-tail modeling; all-success48/54/60/66-byte vectors and whole504-byte heap independently match. All retained allocations/guards, BSS/DATA/display/timer checked after every insertion.',
                        'Original compound16-byte frame restored through58d70. Native allocator/freeing/reuse remain fixtures; raw values have no inferred physical units and no callbacks are invoked.',
                        'Later properties/full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models and opaque color HIGH16 limits persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=32,metric_result=20,success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

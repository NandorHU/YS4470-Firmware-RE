"""Verify two raw color wrappers on HEAP+18 under all growth outcomes."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_metric12_style import Metric12StyleReplay, METRIC12_VECTOR, METRIC12_RETURN, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_compound_growth import vector_bytes
from validate_native_cold_bss import BSS, LENGTH, DATA
from validate_native_display_initializer_prefix import STATE

COLOR_PAIR_RETURN=0x80058D04


class Metric12ColorsReplay(Metric12StyleReplay):
    def __init__(self,raw):
        self.color_pair_phase=False
        self.color_pair_inputs=[]
        self.color_pair_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.color_pair_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc in (0x8003DC18,0x8003DC74):
                self.color_pair_inputs.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)])
            if any(lo<=pc<hi for lo,hi in ((METRIC12_RETURN,COLOR_PAIR_RETURN),
                    (0x8003DC18,0x8003DC34),(0x8003DC74,0x8003DC90))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.color_pair_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0x18<=address and address+size<=HEAP+0x20:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.color_pair_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_color_pair(self,schedule):
        assert len(schedule)==2
        self.run_metric12_style(True)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50),(METRIC12_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values,tags=[10,0xFF],[0x0B,0x21]
        pointer,summary,start=METRIC12_VECTOR,5,METRIC12_RETURN
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.color_pair_phase=True
        steps=[]
        for index,(tag,state_offset,category_bit,success,return_pc) in enumerate(zip(
                (0x20,0x30),(6,8),(4,8),schedule,(0x80058CF4,COLOR_PAIR_RETURN))):
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            assert len(self.color_pair_inputs)==index+1
            style,color,retained=self.color_pair_inputs[index]
            expected_color=struct.unpack('<H',self.u.mem_read(STATE+state_offset,2))[0]
            assert style==HEAP+0x18 and color==expected_color
            payload=(color&0xFFFF)|(retained&0xFFFF0000)
            expected_high=0x1200 if index==0 or schedule[0] else 0
            assert retained>>16==expected_high
            assert payload==expected_color|(expected_high<<16)
            size=6*(len(values)+1)
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,size,0x8003DE90]
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==payload
            assert self.u.mem_read(pointer,len(values)*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x12005000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*size
            self.u.mem_write(target-16,b'\x81'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\x18'*16)
            self.color_pair_buffers[target]=initial
            if success:
                values.append(payload);tags.append(tag);summary|=category_bit;pointer=target
                self.color_pair_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0x18,pointer,0x0B,summary,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc and self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.color_pair_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x81'*16 and self.u.mem_read(a+len(expected),16)==b'\x18'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),raw_payload=hex(payload),wrapper_input=[hex(v) for v in self.color_pair_inputs[index]],
                              actual_requested_bytes=size,outcome_fixture='moving_success' if success else 'null',
                              style_hex=expected_heap[0x18:0x20].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(realloc_success_fixtures=list(schedule),steps=steps,final_tags=[hex(t) for t in tags],
                    final_values=[hex(v) for v in values],final_style_hex=expected_heap[0x18:0x20].hex(),
                    complete_heap_vectors_guards_checked=True,all_prior_vectors_bss_data_display_timer_unchanged=True,
                    caller_sp_preserved=True,stop_pc=hex(COLOR_PAIR_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=2):
            replay=Metric12ColorsReplay(raw);rows.append(replay.run_color_pair(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-metric12-colors.v1',images=images,total_cases=8,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_metric12_style.py'))},
                limits=['Original HEAP+18 color wrappers use STATE+6/+8 lowffff/e71c and opaque incomingR2 HIGH16 under all four null/moving-success realloc schedules. First payload1200ffff; second payload1200e71c after prior success, but0000e71c after prior null because native3de90 set R2=0.',
                        'Every actual pointer/size checked before explicit prefix-copy/poison-tail modeling; all-success18/24-byte vectors and complete504-byte heap independently match. All old/new buffers/guards, BSS/DATA/display/timer and caller SP checked after each insertion.',
                        'Opaque high16 is not an inferred extra channel or physical format. Native allocator/freeing/reuse remain modeled; no stored callbacks invoked.',
                        'Stops58d04 before following properties. Full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=8,raw_payloads=[x['raw_payload'] for x in rows[-1]['steps']],success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

"""Execute the first two cold style primitives in their configuration caller frame."""
import argparse
import hashlib
import json
from pathlib import Path

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_SP
from validate_native_cold_configuration_prefix import ColdConfigurationReplay, STYLE_ENTRY, HEAP, HEAP_BYTES, STATE, OBJECT, DRIVER, TIMER, TIMER_LIST, TIMER_STATE, DISPLAY, BASE

CONSTRUCTOR = 0x8003E080


class ColdStyleReplay(ColdConfigurationReplay):
    def __init__(self, raw):
        self.style_phase = False
        self.style_calls, self.zero_calls = [], []
        super().__init__(raw)

    def code(self, u, pc, size, data):
        if self.style_phase:
            if pc == self.stop:
                u.emu_stop()
                return
            if pc == STYLE_ENTRY:
                self.style_calls.append([u.reg_read(UC_ARM_REG_R0), u.reg_read(UC_ARM_REG_LR)])
            if pc == 0x80032E14:
                args = [u.reg_read(r) for r in (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_LR)]
                assert args in ([HEAP+0xD0, 8, 0x80058AF0], [HEAP+0xD8, 8, 0x80058AFC])
                self.zero_calls.append(args)
            if any(lo <= pc < hi for lo, hi in ((STYLE_ENTRY, 0x8005A34C),
                    (0x8003D828, 0x8003D830), (0x80058AE4, 0x80058B18))):
                assert size == 4
                self.coverage[pc] = bytes(u.mem_read(pc, size)).hex()
                return
        super().code(u, pc, size, data)

    def write(self, u, access, address, size, value, data):
        if self.style_phase and HEAP+0xD0 <= address and address+size <= HEAP+0xE0:
            assert 0x80032E14 <= u.reg_read(UC_ARM_REG_PC) < 0x80032EA4
            assert value == 0
            return
        super().write(u, access, address, size, value, data)

    def run_style_zero(self):
        self.run_cold_configuration()
        snapshots = {a: bytes(self.u.mem_read(a, n)) for a, n in
                     ((STATE,20),(OBJECT,36),(DRIVER,80),(TIMER,32),
                      (TIMER_LIST,12),(TIMER_STATE,20),(DISPLAY,0x15C))}
        sp = self.u.reg_read(UC_ARM_REG_SP)
        expected_heap = bytearray(b'\xA5'*HEAP_BYTES)
        expected_heap[0xD0:0xE0] = bytes(16)
        self.style_phase = True
        self.stop = CONSTRUCTOR
        self.u.emu_start(STYLE_ENTRY, 0, count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC) == CONSTRUCTOR
        assert self.u.reg_read(UC_ARM_REG_SP) == sp
        assert self.style_calls == [[HEAP+0xD0,0x80058AF0],[HEAP+0xD8,0x80058AFC]]
        assert len(self.zero_calls) == 2
        assert self.u.mem_read(HEAP,HEAP_BYTES) == expected_heap
        assert self.u.mem_read(HEAP-16,16) == b'\x6E'*16
        assert self.u.mem_read(HEAP+HEAP_BYTES,16) == b'\xE6'*16
        for address, expected in snapshots.items():
            assert self.u.mem_read(address,len(expected)) == expected
        # First following native call is only observed at entry, not executed.
        arguments = [self.u.reg_read(r) for r in (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3)]
        expected_arguments = [self.word(0x800599F4),self.word(0x800599F0),self.word(0x800599EC),0x50]
        assert arguments == expected_arguments
        assert self.u.reg_read(UC_ARM_REG_LR) == 0x80058B18
        assert [self.word(sp),self.word(sp+4)] == [0x46,0]
        return dict(native_style_calls=[[hex(a),hex(lr)] for a,lr in self.style_calls],
                    native_zero_calls=[[hex(a),n,hex(lr)] for a,n,lr in self.zero_calls],
                    heap_bytes=HEAP_BYTES,zeroed_heap_offsets=[0xD0,0xE0],
                    complete_heap_sha256=hashlib.sha256(expected_heap).hexdigest(),
                    globals_and_guards_unchanged=True,caller_sp_preserved=True,state_byte0=0,
                    next_call_arguments=[hex(a) for a in arguments],next_call_stack=[0x46,0],
                    next_call_return='0x80058b18',stop_pc=hex(CONSTRUCTOR),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args()
    repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={ },[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=ColdStyleReplay(raw)
        observations.append((replay.run_style_zero(),replay.coverage))
    assert observations[0]==observations[1]
    row,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-style-zero.v1',images=images,total_cases=2,cases=[row],
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_configuration_prefix.py'))},
                limits=['Two original style wrapper calls read cold STATE byte0=0 and tail-call original8-byte initialization/memzero; prior poisoned504-byte heap matches independent complete reference.',
                        'Actual caller frame preserved, all preceding state/object/display/timer/driver bytes and heap guards unchanged. No free/reallocation branch is forced.',
                        'Stops at following native0x8003e080 entry; arguments/literals and stack captured but body not executed. Initializer not returned; no roots/callback firing/physical timing claim.',
                        'Existing cold DATA/BSS effect and hardware/heap/raw-clock/list-manager models remain explicit.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=2,next_arguments=row['next_call_arguments'],stop=row['stop_pc'])))


if __name__=='__main__':main()

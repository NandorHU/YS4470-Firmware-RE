"""Verify null and guarded-success outcomes at the captured12-byte allocation."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_SP
from validate_native_cold_first_allocation import FirstAllocationReplay, ALLOC, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA

GROWTH = 0x11007000
AFTER_GROWTH = 0x80058BA8


class GrowthOutcomeReplay(FirstAllocationReplay):
    def __init__(self, raw):
        self.outcome_phase = False
        super().__init__(raw)

    def write(self,u,access,address,size,value,data):
        if self.outcome_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+8 <= address and address+size <= HEAP+16:
                assert pc in (0x8003DF30,0x8003DF44,0x8003DF98)
                return
            if GROWTH <= address and address+size <= GROWTH+12:
                assert pc in (0x8003DF4C,0x8003DF50,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_outcome(self,success):
        self.run_allocation_entry()
        assert self.u.reg_read(UC_ARM_REG_PC)==ALLOC
        assert self.u.reg_read(UC_ARM_REG_R0)==12
        assert self.u.reg_read(UC_ARM_REG_LR)==0x8003DF24
        suspended_sp=self.u.reg_read(UC_ARM_REG_SP)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32))}
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        expected_growth=bytearray(b'\xA5'*12)
        self.u.mem_write(GROWTH-16,b'\x6F'*16)
        self.u.mem_write(GROWTH,bytes(expected_growth))
        self.u.mem_write(GROWTH+12,b'\xF6'*16)
        if success:
            struct.pack_into('<IHBB',expected_heap,8,GROWTH,0x20,0x05,2)
            struct.pack_into('<IIHH',expected_growth,0,0x9CF3,0x7FFF,0x20,0x0B)
        self.outcome_phase=True
        self.stop=AFTER_GROWTH
        self.u.reg_write(UC_ARM_REG_R0,GROWTH if success else 0)
        # Only this captured allocation result is modeled; native continuation runs.
        self.u.emu_start(0x8003DF24,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==AFTER_GROWTH
        assert self.u.reg_read(UC_ARM_REG_SP)==suspended_sp+32
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(GROWTH,12)==expected_growth
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16
        assert self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        assert self.u.mem_read(GROWTH-16,16)==b'\x6F'*16
        assert self.u.mem_read(GROWTH+12,16)==b'\xF6'*16
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected))==expected
        return dict(allocator_outcome_fixture='guarded_success' if success else 'null',
                    modeled_allocation_bytes=12,modeled_return=hex(GROWTH if success else 0),
                    native_resume='0x8003df24',style_hex=expected_heap[8:16].hex(),
                    growth_hex=expected_growth.hex(),complete_heap_reference=True,
                    complete_bss_data_display_timer_unchanged=True,all_guards_unchanged=True,
                    caller_stack_restored_bytes=32,stop_pc=hex(AFTER_GROWTH),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for success in (False,True):
            replay=GrowthOutcomeReplay(raw);rows.append(replay.run_outcome(success));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-growth-outcomes.v1',images=images,total_cases=4,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_first_allocation.py'))},
                limits=['Captured12-byte allocation outcome explicitly modeled as null or guarded success; original continuation executes through caller58ba8 without executing allocator implementation.',
                        'Null outcome leaves original inline style and growth poison unchanged. Success moves prior value/tag and adds7fff/tag0b into independently checked12-byte vector; style becomes count2,summary05,pointer to vector with retained20 halfword.',
                        'Entire504-byte heap,12-byte allocation, both allocation guard pairs, complete BSS/DATA/display/timer references and32-byte suspended-frame restoration checked.',
                        'Allocator implementation/reuse, later reallocations, remaining configuration/initializer return, roots, callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=4,outcomes=[r['allocator_outcome_fixture'] for r in rows],success_style=rows[1]['style_hex'],success_vector=rows[1]['growth_hex'])))


if __name__=='__main__':main()

"""Initialize two additional cold styles and capture base-style color growth."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_record_properties import RecordPropertiesReplay, AFTER_RECORDS, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_first_allocation import ALLOC, COLOR_WRAPPER
from validate_native_cold_bss import BSS, LENGTH, DATA
from validate_native_display_initializer_prefix import STATE


class BaseStyleEntryReplay(RecordPropertiesReplay):
    def __init__(self,raw):
        self.base_style_phase=False
        self.base_zero_calls=[]
        self.base_color_input=None
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.base_style_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80032E14:
                self.base_zero_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)])
            if pc==COLOR_WRAPPER:
                self.base_color_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if any(lo<=pc<hi for lo,hi in ((AFTER_RECORDS,0x80058C3C),(0x8005A334,0x8005A34C),
                    (0x8003D828,0x8003D830),(0x8003DC68,0x8003DC74),(COLOR_WRAPPER,0x8003DC34))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.base_style_phase and any(a<=address and address+size<=a+8 for a in (HEAP,HEAP+0x10)):
            pc=u.reg_read(UC_ARM_REG_PC)
            assert 0x80032E14<=pc<0x80032EA4 or pc in (0x8003DF78,0x8003DDF0,0x8003DDF4,0x8003DF98)
            return
        super().write(u,access,address,size,value,data)

    def run_base_style_entry(self):
        self.run_record_properties((True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (GROWTH-16,44),(MOVED-16,50),(NEW-16,74))}
        for buffers in (self.compound_buffers,self.record_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        for offset in (0,0x10):struct.pack_into('<IHBB',expected_heap,offset,0xFF,0x21,4,1)
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.base_style_phase=True
        self.stop=ALLOC
        self.u.emu_start(AFTER_RECORDS,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==ALLOC
        assert self.base_zero_calls==[[HEAP+0x10,8,0x80058C0C],[HEAP,8,0x80058C24]]
        assert self.base_color_input is not None
        style,color,retained=self.base_color_input
        expected_color=struct.unpack('<H',self.u.mem_read(STATE+2,2))[0]
        assert style==HEAP and color==expected_color==0xF7BE
        payload=expected_color|(retained&0xFFFF0000)
        assert self.u.reg_read(UC_ARM_REG_R8)==0x20 and self.u.reg_read(UC_ARM_REG_R9)==payload
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_LR)]==[12,0x8003DF24]
        assert self.u.reg_read(UC_ARM_REG_SP)==sp-32
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():assert self.u.mem_read(address,len(expected))==expected
        return dict(native_zero_calls=[[hex(a),n,hex(lr)] for a,n,lr in self.base_zero_calls],
                    first_base_inline_hex=expected_heap[:8].hex(),second_inline_hex=expected_heap[16:24].hex(),
                    color_input=[hex(v) for v in self.base_color_input],color_low_halfword=hex(expected_color),
                    opaque_retained_halfword=hex((retained>>16)&0xFFFF),pending_tag='0x20',pending_raw_payload=hex(payload),
                    allocation_bytes=12,allocator_return='0x8003df24',allocator_executed=False,
                    complete_heap_reference=True,all_old_vectors_bss_data_display_timer_guards_unchanged=True,
                    suspended_property_frame_bytes=32,stop_pc=hex(ALLOC),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=BaseStyleEntryReplay(raw);observations.append((replay.run_base_style_entry(),replay.coverage))
    assert observations[0]==observations[1]
    row,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-base-style-entry.v1',images=images,total_cases=2,cases=[row],
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_record_properties.py'))},
                limits=['Two further original cold style initializations and tag21/rawff inline stores execute at HEAP+10 and HEAP+0; complete504-byte heap independently checked.',
                        'Base color wrapper reads STATE+2=f7be, preserves incoming R2 high16 as opaque upper payload, then native differing-tag path requests12-byte allocation. Stops before allocator outcome is modeled.',
                        'Whole prior BSS/DATA/display/timer and all old vectors/guards unchanged;32-byte property frame suspended. Retained upper payload is not an extra color channel or format claim.',
                        'Remaining configuration/initializer return, roots/callbacks, allocator implementation/reuse and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=2,inline=row['first_base_inline_hex'],pending_payload=row['pending_raw_payload'],allocation_bytes=12)))


if __name__=='__main__':main()

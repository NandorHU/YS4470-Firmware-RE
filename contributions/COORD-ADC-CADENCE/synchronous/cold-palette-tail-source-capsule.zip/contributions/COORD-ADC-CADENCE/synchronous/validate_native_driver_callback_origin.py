"""Prove native default driver+0x1c initialization from poisoned driver RAM."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1
from trace_display_refresh_setup import SetupReplay, BASE, DRIVER, DISPLAY, CONTEXT, PANEL_FRAME


class DriverOriginReplay(SetupReplay):
    def __init__(self,raw):
        self.driver_zero_calls=[];self.callback_field_writes=[]
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if pc==0x80032E14 and u.reg_read(UC_ARM_REG_R0)==DRIVER:
            length=u.reg_read(UC_ARM_REG_R1);lr=u.reg_read(UC_ARM_REG_LR)
            assert length==0x50 and 0x800259B4<=lr<0x80025A54
            self.driver_zero_calls.append(dict(entry=hex(pc),return_to=hex(lr),destination=hex(DRIVER),bytes=length))
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if address<DRIVER+0x20 and address+size>DRIVER+0x1C:
            pc=u.reg_read(UC_ARM_REG_PC)
            assert 0x80032E14<=pc<0x80032EA4
            encoded=value.to_bytes(size,'little')
            lo=max(address,DRIVER+0x1C);hi=min(address+size,DRIVER+0x20)
            assert encoded[lo-address:hi-address]==bytes(hi-lo)
            self.callback_field_writes.append(dict(pc=hex(pc),address=hex(address),size=size,value=value))
        super().write(u,access,address,size,value,data)

    def run_origin(self):
        self.u.mem_write(DRIVER,b'\xA5'*0x50)
        self.u.mem_write(DRIVER-16,b'\x7D'*16)
        self.u.mem_write(DRIVER+0x50,b'\xD7'*16)
        assert self.word(DRIVER+0x1C)==0xA5A5A5A5
        self.execute(0x8003B080,0x80025AC8)
        assert len(self.driver_zero_calls)==1 and self.callback_field_writes
        assert self.word(DRIVER+0x1C)==0
        assert self.u.mem_read(DRIVER-16,16)==b'\x7D'*16
        assert self.u.mem_read(DRIVER+0x50,16)==b'\xD7'*16
        assert struct.unpack('<2H',self.u.mem_read(DRIVER,4))==(480,854)
        assert self.word(DRIVER+0x10)==0x413C
        assert self.word(DRIVER+0x14)==0x800115F4
        assert self.word(DRIVER+0x3C)==CONTEXT
        assert self.word(DRIVER+0x40)==0x80029CC8 and self.word(DISPLAY)==DRIVER
        assert self.word(CONTEXT+0x3C)==0x80029F24
        assert self.word(CONTEXT+0x40)==0x80029D9C
        assert self.word(CONTEXT+0x54)==0x80028A5C
        assert self.hardware_calls==[[480,854,PANEL_FRAME,0]]
        return dict(entry='0x8003b080',stop_pc='0x80025ac8',native_driver=hex(DRIVER),
                    caller_poison_byte='0xa5',driver_zero_calls=self.driver_zero_calls,
                    callback_field_offset='0x1c',final_callback_word=0,callback_field_native_writes=self.callback_field_writes,
                    final_driver_hex=bytes(self.u.mem_read(DRIVER,0x50)).hex(),driver_guard_bytes_unchanged=True,
                    native_context_initializer=hex(self.word(DRIVER+0x40)),
                    native_layer_create=hex(self.word(CONTEXT+0x3C)),native_layer_bind=hex(self.word(CONTEXT+0x40)),
                    native_blend=hex(self.word(CONTEXT+0x54)),modeled_hardware_call_arguments=[480,854,hex(PANEL_FRAME),0])


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()
    manifest=json.loads(Path('original-firmware/manifest.json').read_bytes())
    images,originals,observed={},[],[]
    for item in manifest['images']:
        raw=Path(item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=DriverOriginReplay(raw)
        observed.append((replay.run_origin(),replay.coverage))
    assert observed[0]==observed[1]
    case,coverage=observed[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in coverage.items())
    report=dict(schema='ys4470.native-driver-callback-origin.v1',images=images,total_cases=2,cases=[case],
                instruction_bytes={hex(pc):word for pc,word in sorted(coverage.items())},
                source_sha256={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in (Path(__file__).name,'trace_display_refresh_setup.py')},
                limits=['Original display setup/driver initialization/registration prefix executes from0x8003b080 through0x80025ac4 with entire80-byte driver RAM initially poisoned A5.',
                        'Original driver initialization calls actual memzero for exactly80 bytes; every write overlapping driver+0x1c is recorded inside the original zero primitive, leaves zero and no later prefix writer replaces it. Both16-byte allocation-adjacent driver guards unchanged.',
                        'Original default driver flags0x413c and native context initializer/create/bind/blend pointers checked. The zero callback field is initialized by real native code, not assumed from initially zero RAM.',
                        'Hardware initializer, display-node and context allocations remain modeled. Stops at registration prefix; later writers, other driver instances/backends, legitimate bit6-set storage state, physical LCD and timing remain open.'])
    args.out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print('PASS 2 poisoned-RAM native driver callback-origin cases')


if __name__=='__main__':main()

"""Complete the remaining three compound tags under every realloc outcome schedule."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_SP
from validate_native_cold_reallocation_outcomes import ReallocationOutcomeReplay, MOVED, FIRST_RETURN, GROWTH, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

CALLER_RETURN = 0x80058BC4


def vector_bytes(values,tags):
    return struct.pack('<'+'I'*len(values)+'H'*len(tags),*values,*tags)


class CompoundReplay(ReallocationOutcomeReplay):
    def __init__(self,raw):
        self.compound_phase=False
        self.compound_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.compound_phase and pc==self.stop:
            u.emu_stop()
            return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.compound_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+8<=address and address+size<=HEAP+16:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.compound_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_compound(self,schedule):
        assert len(schedule)==3
        self.run_reallocation_outcome(True)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),(MOVED-16,50))}
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values,tags,pointer=[0x9CF3,0x7FFF,6],[0x20,0x0B,0x12],MOVED
        start=FIRST_RETURN
        compound_sp=self.u.reg_read(UC_ARM_REG_SP)
        observations=[]
        self.compound_phase=True
        for index,(tag,success,return_pc) in enumerate(zip((0x13,0x10,0x11),schedule,(0x8003DD80,0x8003DD8C,CALLER_RETURN))):
            count=len(values);new_size=6*(count+1)
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,new_size,0x8003DE90]
            assert self.u.mem_read(pointer,count*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x11009000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*new_size
            self.u.mem_write(target-16,b'\x78'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+new_size,b'\x87'*16)
            self.compound_buffers[target]=initial
            if success:
                values.append(6);tags.append(tag);pointer=target
                self.compound_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,8,pointer,0x20,7,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for address,expected in self.compound_buffers.items():
                assert self.u.mem_read(address,len(expected))==expected
                assert self.u.mem_read(address-16,16)==b'\x78'*16
                assert self.u.mem_read(address+len(expected),16)==b'\x87'*16
            for address,expected in snapshots.items():
                assert self.u.mem_read(address,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16
            assert self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            observations.append(dict(tag=hex(tag),value=6,outcome_fixture='moving_success' if success else 'null',
                                     actual_requested_bytes=new_size,old_pointer=hex(args[0]),new_pointer=hex(pointer),
                                     style_hex=expected_heap[8:16].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        assert self.u.reg_read(UC_ARM_REG_SP)==compound_sp+16
        return dict(remaining_realloc_success_fixtures=list(schedule),steps=observations,
                    final_values=values,final_tags=[hex(t) for t in tags],final_count=len(values),
                    final_style_hex=expected_heap[8:16].hex(),complete_heap_vectors_guards_checked=True,
                    complete_bss_data_display_timer_unchanged=True,compound_frame_restored_bytes=16,
                    stop_pc=hex(CALLER_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=3):
            replay=CompoundReplay(raw);rows.append(replay.run_compound(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-compound-growth.v1',images=images,total_cases=16,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_reallocation_outcomes.py'))},
                limits=['After prior tag12 success fixture, all eight null/moving-success schedules execute remaining original compound tags13/10/11,value6, through caller58bc4. Actual realloc pointers/sizes checked before each modeled outcome.',
                        'Every successful growth uses explicit prefix-copy/poison-tail fixture and independent complete value/tag vector; every null leaves prior state unchanged. Whole504-byte heap, all retained old/new vectors/guards and BSS/DATA/display/timer references checked after every step.',
                        'Original compound16-byte frame restored; native allocator implementation/freeing/reuse not executed. Values remain raw; configuration/initializer return, roots/callbacks and physical timing remain open.',
                        'Prior cold DATA/BSS effect and hardware/heap/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=16,schedules=8,all_success_final_tags=rows[-1]['final_tags'],all_success_sizes=[step['actual_requested_bytes'] for step in rows[-1]['steps']])))


if __name__=='__main__':main()

"""Execute two actual STATEbyte1 metric14 branches and property-growth schedules."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_secondary_color import SecondaryColorReplay, SECONDARY_VECTOR, HIGH_BRANCH, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_compound_growth import vector_bytes
from validate_native_cold_bss import BSS, LENGTH, DATA

METRIC14_RETURN=0x80058CA0


class Metric14Replay(SecondaryColorReplay):
    def __init__(self,raw):
        self.metric14_phase=False
        self.metric14_calls,self.metric14_results=[],[]
        self.metric14_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.metric14_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,14]
                self.metric14_calls.append(args)
            if pc==0x800259AC:self.metric14_results.append(u.reg_read(UC_ARM_REG_R0))
            if any(lo<=pc<hi for lo,hi in ((HIGH_BRANCH,0x80058F40),(0x80058C68,METRIC14_RETURN),
                    (0x80025958,0x800259B0),(0x80025CA4,0x80025CD4),(0x8003DDA8,0x8003DDE4))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.metric14_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP<=address and address+size<=HEAP+8:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.metric14_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_metric14(self,schedule):
        assert len(schedule)==2
        self.run_secondary(True)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (GROWTH-16,44),(MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50))}
        for buffers in (self.compound_buffers,self.record_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values,tags=[0xFF,0x1100F7BE,0x12002104],[0x21,0x20,0x55]
        pointer,summary,start=SECONDARY_VECTOR,0x24,HIGH_BRANCH
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.tag1_phase=False  # Its earlier helper admission allowed only5.
        self.reallocation_entry_phase=False
        self.metric14_phase=True
        steps=[]
        for index,(tag,success,return_pc) in enumerate(zip((0x14,0x15),schedule,(0x80058C74,METRIC14_RETURN))):
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            value=(130*14+80)//160
            assert value==11 and self.metric14_results==[11]*(index+1)
            size=6*(len(values)+1)
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,size,0x8003DE90]
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(pointer,len(values)*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x12002000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*size
            self.u.mem_write(target-16,b'\x7D'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\xD7'*16)
            self.metric14_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);summary|=2;pointer=target
                self.metric14_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0,pointer,0x21,summary,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc
            assert self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.metric14_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x7D'*16 and self.u.mem_read(a+len(expected),16)==b'\xD7'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),value=value,actual_requested_bytes=size,
                              outcome_fixture='moving_success' if success else 'null',
                              style_hex=expected_heap[:8].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        assert self.metric14_calls==[[DISPLAY,14],[DISPLAY,14]]
        return dict(realloc_success_fixtures=list(schedule),metric14_results=self.metric14_results,steps=steps,
                    final_tags=[hex(t) for t in tags],final_values=[hex(v) for v in values],
                    final_style_hex=expected_heap[:8].hex(),complete_heap_vectors_guards_checked=True,
                    all_prior_vectors_bss_data_display_timer_unchanged=True,caller_sp_preserved=True,
                    stop_pc=hex(METRIC14_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=2):
            replay=Metric14Replay(raw);rows.append(replay.run_metric14(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-metric14-properties.v1',images=images,total_cases=8,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_secondary_color.py'))},
                limits=['Actual STATEbyte1 branch stubs58f20/58f30 execute original25958(DISPLAY,14), result11 each, and tags14/15 insertions under all four null/moving-success realloc schedules.',
                        'Each actual pointer/size checked before modeled prefix-copy/poison-tail; all-success sizes24/30. Complete vectors/504-byte heap, all old/new guards, whole BSS/DATA/display/timer and caller SP independently checked after each insertion.',
                        'Raw encoded-driver scaling is not assigned DPI/physical units. Native allocator/freeing/reuse remain unexecuted fixtures; opaque color payload halves retain prior limits.',
                        'Stops58ca0 before next HEAP+18 style init. Remaining configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=8,metric_results=rows[-1]['metric14_results'],success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

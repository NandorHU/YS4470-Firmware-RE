"""Check guarded base-style color allocation outcomes with opaque high16 retained."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_SP
from validate_native_cold_base_style_entry import BaseStyleEntryReplay, ALLOC, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA

ARENA=0x12000000
BASE_VECTOR=ARENA+0x100
BASE_RETURN=0x80058C3C


class BaseStyleOutcomeReplay(BaseStyleEntryReplay):
    def __init__(self,raw):
        self.base_outcome_phase=False
        super().__init__(raw)
        self.u.mem_map(ARENA,0x10000)

    def write(self,u,access,address,size,value,data):
        if self.base_outcome_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP<=address and address+size<=HEAP+8:
                assert pc in (0x8003DF30,0x8003DF44,0x8003DF98)
                return
            if BASE_VECTOR<=address and address+size<=BASE_VECTOR+12:
                assert pc in (0x8003DF4C,0x8003DF50,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_base_outcome(self,success):
        self.run_base_style_entry()
        assert self.u.reg_read(UC_ARM_REG_PC)==ALLOC
        assert self.u.reg_read(UC_ARM_REG_R0)==12 and self.u.reg_read(UC_ARM_REG_LR)==0x8003DF24
        suspended_sp=self.u.reg_read(UC_ARM_REG_SP)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (GROWTH-16,44),(MOVED-16,50),(NEW-16,74))}
        for buffers in (self.compound_buffers,self.record_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        expected_vector=b'\xA5'*12
        self.u.mem_write(BASE_VECTOR-16,b'\x7B'*16)
        self.u.mem_write(BASE_VECTOR,expected_vector)
        self.u.mem_write(BASE_VECTOR+12,b'\xB7'*16)
        payload=(self.base_color_input[1]&0xFFFF)|(self.base_color_input[2]&0xFFFF0000)
        assert payload==0x1100F7BE
        if success:
            expected_vector=struct.pack('<IIHH',0xFF,payload,0x21,0x20)
            struct.pack_into('<IHBB',expected_heap,0,BASE_VECTOR,0x21,4,2)
        self.base_outcome_phase=True
        self.stop=BASE_RETURN
        self.u.reg_write(UC_ARM_REG_R0,BASE_VECTOR if success else 0)
        self.u.emu_start(0x8003DF24,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==BASE_RETURN
        assert self.u.reg_read(UC_ARM_REG_SP)==suspended_sp+32
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(BASE_VECTOR,12)==expected_vector
        assert self.u.mem_read(BASE_VECTOR-16,16)==b'\x7B'*16
        assert self.u.mem_read(BASE_VECTOR+12,16)==b'\xB7'*16
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():assert self.u.mem_read(address,len(expected))==expected
        return dict(allocation_outcome_fixture='guarded_success' if success else 'null',
                    modeled_bytes=12,separate_arena=hex(ARENA),modeled_return=hex(BASE_VECTOR if success else 0),
                    raw_color_payload=hex(payload),opaque_retained_high16='0x1100',
                    style_hex=expected_heap[:8].hex(),vector_hex=expected_vector.hex(),
                    complete_heap_and_vector_references=True,all_prior_vectors_bss_data_display_timer_guards_unchanged=True,
                    caller_stack_restored_bytes=32,stop_pc=hex(BASE_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for success in (False,True):
            replay=BaseStyleOutcomeReplay(raw);rows.append(replay.run_base_outcome(success));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-base-style-outcomes.v1',images=images,total_cases=4,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_base_style_entry.py'))},
                limits=['Captured base-style12-byte allocation explicitly modeled as null or guarded success in separately mapped arena12000000; original3df24 continuation executes to58c3c with32-byte frame restoration.',
                        'Success independently verifies vector valuesff/1100f7be,tags21/20 and style count2/summary04. The opaque1100 payload halfword is preserved HIGH16, not an extra color-channel/format claim. Null leaves inline style and allocation poison unchanged.',
                        'Entire504-byte heap, new12-byte vector/guards, all prior vectors/guards, whole BSS/DATA/display/timer checked. Native allocator implementation/freeing/reuse not executed.',
                        'Remaining configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=4,success_style=rows[1]['style_hex'],success_vector=rows[1]['vector_hex'],stop=rows[1]['stop_pc'])))


if __name__=='__main__':main()

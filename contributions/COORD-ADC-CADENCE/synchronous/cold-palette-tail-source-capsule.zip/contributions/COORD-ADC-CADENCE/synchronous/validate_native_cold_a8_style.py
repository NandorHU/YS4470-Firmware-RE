"""Verify HEAP+a8 halfword-source style under all two-growth allocation outcomes."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R6, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_a0_style import A0StyleReplay, A0_RETURN, METRIC12_VECTOR, SECONDARY_VECTOR, BASE_VECTOR, NEW, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE, vector_bytes, ALLOC, REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

A8_INLINE_RETURN=0x80058E88
A8_RETURN=0x80058EB4


class A8StyleReplay(A0StyleReplay):
    def __init__(self,raw):
        self.a8_phase=False
        self.a8_input=None
        self.a8_zero_calls,self.a8_metric_calls,self.a8_metric_results=[],[],[]
        self.a8_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.a8_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if pc==0x8003DD24:
                self.a8_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
            if pc==0x80032E14:
                self.a8_zero_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)])
            if pc==0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,3]
                self.a8_metric_calls.append(args)
            if pc==0x800259AC:self.a8_metric_results.append(u.reg_read(UC_ARM_REG_R0))
            if any(lo<=pc<hi for lo,hi in ((A0_RETURN,A8_RETURN),(0x8003DD24,0x8003DD64),
                    (0x8005A334,0x8005A34C),(0x8003D828,0x8003D830),
                    (0x80025958,0x800259B0),(0x80025CA4,0x80025CD4))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.a8_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+0xA8<=address and address+size<=HEAP+0xB0:
                assert 0x80032E14<=pc<0x80032EA4 or pc in (0x8003DF78,0x8003DDF0,0x8003DDF4,
                    0x8003DF98,0x8003DF30,0x8003DF44,0x8003DE98,0x8003DED0)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.a8_buffers.items()):
                assert pc in (0x8003DF4C,0x8003DF50,0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_a8_style(self,schedule):
        assert len(schedule)==2
        self.run_a0_style((True,True,True))
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44),
                    (MOVED-16,50),(NEW-16,74),(BASE_VECTOR-16,44),(SECONDARY_VECTOR-16,50),(METRIC12_VECTOR-16,44))}
        for buffers in (self.compound_buffers,self.record_buffers,self.metric14_buffers,self.color_pair_buffers,
                        self.metric2_buffers,self.metric24_buffers,self.padding14_buffers,self.palette_metric_buffers,self.a0_buffers):
            for a,raw in buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.a0_phase=False
        self.a8_phase=True
        self.stop=A8_INLINE_RETURN
        self.u.emu_start(A0_RETURN,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==A8_INLINE_RETURN and self.u.reg_read(UC_ARM_REG_SP)==sp
        assert self.a8_zero_calls==[[HEAP+0xA8,8,0x80058E78]]
        source_base=self.u.reg_read(UC_ARM_REG_R6)
        source_halfword=struct.unpack('<H',self.u.mem_read(source_base+0x3A,2))[0]
        assert source_base==0x807B52D0 and source_halfword==self.palette0==0xF206
        assert self.a8_input[0:2]==[HEAP+0xA8,source_halfword] and self.a8_input[2]>>16==0
        first=source_halfword|(self.a8_input[2]&0xFFFF0000)
        struct.pack_into('<IHBB',expected_heap,0xA8,first,0x36,8,1)
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        values,tags,pointer,start=[first],[0x36],None,A8_INLINE_RETURN
        steps=[]
        for index,(tag,value,success,return_pc) in enumerate(zip((0x35,0x37),(2,0x7F),schedule,(0x80058EA4,A8_RETURN))):
            count=len(values);api=ALLOC if count==1 else REALLOC;resume=0x8003DF24 if count==1 else 0x8003DE90
            size=6*(count+1)
            self.stop=api
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==api
            assert self.a8_metric_calls==[[DISPLAY,3]] and self.a8_metric_results==[(130*3+80)//160]==[2]
            if count==1:
                assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_LR)]==[12,resume]
            else:
                assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]==[pointer,size,resume]
                assert self.u.mem_read(pointer,count*6)==vector_bytes(values,tags)
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x12015000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success and count>1 else b'\xA5'*size
            self.u.mem_write(target-16,b'\x87'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\x78'*16)
            self.a8_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);pointer=target
                self.a8_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,0xA8,pointer,0x36,8,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(resume,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc and self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.a8_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x87'*16 and self.u.mem_read(a+len(expected),16)==b'\x78'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),raw_value=hex(value),actual_api=hex(api),actual_requested_bytes=size,
                              outcome_fixture='guarded_success' if success else 'null',
                              style_hex=expected_heap[0xA8:0xB0].hex(),vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(allocation_success_fixtures=list(schedule),source_base=hex(source_base),source_offset='0x3a',
                    raw_source_halfword=hex(source_halfword),first_wrapper_input=[hex(v) for v in self.a8_input],
                    first_inline_payload=hex(first),steps=steps,metric3_results=self.a8_metric_results,
                    final_tags=[hex(t) for t in tags],final_values=[hex(v) for v in values],
                    final_style_hex=expected_heap[0xA8:0xB0].hex(),complete_heap_vectors_guards_checked=True,
                    all_prior_vectors_bss_data_display_timer_unchanged=True,caller_sp_preserved=True,
                    stop_pc=hex(A8_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=2):
            replay=A8StyleReplay(raw);rows.append(replay.run_a8_style(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-a8-style.v1',images=images,total_cases=8,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_a0_style.py'))},
                limits=['Original cold HEAP+a8 init reads halfwordf206 at807b52d0+3a, tag36 wrapper retains opaque incoming HIGH16=0. Native metric3/raw2 and raw7f enter tags35/37; this style has no tag38.',
                        'All four null/guarded-success schedules distinguish native count1 allocator32800/12 from count>1 realloc32ae4, with exact arguments checked before explicit prefix-copy/poison-tail outcome modeling.',
                        'Each complete vector/504-byte heap and every old/newguard,BSS/DATA/display/timer and caller SP independently checked. Native allocator/free/reuse and raw-field physical meanings remain unclaimed.',
                        'Stops58eb4 before next style. Full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager and opaque HIGH16 limits persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=8,source_halfword=rows[-1]['raw_source_halfword'],success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()

"""Check original third scatter descriptor against a complete poisoned BSS reference."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys

from unicorn import Uc, UC_ARCH_ARM, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm_const import *

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from trace_profiles import restore_globals, V36_SHA, V38_SHA

BASE = 0x7FFFFFE0
MAP = 0x7FFF0000
SIZE = 0x2100000
DATA = 0x805AAAB4
BSS = 0x805AC098
LENGTH = 0x7AF808
END = BSS + LENGTH
RETURN = 0x81FFF000
STACK = 0x81FF0000


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def run(raw):
    assert sha(raw) in (V36_SHA, V38_SHA)
    descriptor = struct.unpack_from('<4I', raw, 0x805AAA88 - BASE)
    assert descriptor == (0x805AAF1C, BSS, LENGTH, 0x8000014C)
    initialized = restore_globals(raw)
    u = Uc(UC_ARCH_ARM, UC_MODE_ARM)
    u.ctl_set_cpu_model(UC_CPU_ARM_926)
    u.mem_map(MAP, SIZE)
    u.mem_write(BASE, raw)
    # The existing hash-pinned original first-two-descriptor replay supplies DATA.
    # Poison the entire third descriptor destination before native zeroing.
    u.mem_write(DATA, initialized)
    u.mem_write(BSS, b'\xA5' * LENGTH)
    u.mem_write(END, b'\xD7' * 32)
    before = bytes(u.mem_read(MAP, SIZE))
    coverage = {}
    instructions = 0

    def code(machine, pc, size, _):
        nonlocal instructions
        assert 0x8000014C <= pc <= 0x80000174 and size == 4
        instructions += 1
        coverage[pc] = bytes(machine.mem_read(pc, size)).hex()

    u.hook_add(UC_HOOK_CODE, code)
    for register, value in ((UC_ARM_REG_CPSR, 0x13), (UC_ARM_REG_R0, descriptor[0]),
                            (UC_ARM_REG_R1, BSS), (UC_ARM_REG_R2, LENGTH),
                            (UC_ARM_REG_SP, STACK), (UC_ARM_REG_LR, RETURN)):
        u.reg_write(register, value)
    u.emu_start(descriptor[3], RETURN, count=2000000)
    assert u.reg_read(UC_ARM_REG_PC) == RETURN
    assert u.reg_read(UC_ARM_REG_SP) == STACK
    assert u.reg_read(UC_ARM_REG_R1) == END
    after = bytes(u.mem_read(MAP, SIZE))
    expected = bytearray(before)
    expected[BSS-MAP:END-MAP] = bytes(LENGTH)
    assert after == expected  # Includes complete DATA, code, guards and all mapped RAM.
    assert bytes(u.mem_read(DATA, len(initialized))) == initialized
    assert bytes(u.mem_read(0x807B52F8, 36)) == bytes(36)
    fields = {hex(a): bytes(u.mem_read(a, n)).hex() for a, n in
              ((0x805ABD84, 4), (0x805ABC6C, 20), (0x807B52F8, 36))}
    row = dict(descriptor=[hex(x) for x in descriptor], bss_start=hex(BSS),
               bss_end_exclusive=hex(END), bss_bytes=LENGTH,
               complete_bss_sha256=sha(bytes(LENGTH)),
               initialized_data_sha256=sha(initialized), globals=fields,
               executed_instructions=instructions, final_r1=hex(u.reg_read(UC_ARM_REG_R1)),
               full_mapped_memory_reference=True, caller_sp_preserved=True)
    return row, coverage


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[3]
    manifest = json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images, rows, all_words = {}, [], []
    for item in manifest['images']:
        raw = (repo/item['path']).read_bytes()
        assert sha(raw) == item['sha256'] and len(raw) == item['size_bytes']
        images[item['version']] = sha(raw)
        row, words = run(raw)
        assert all(raw[pc-BASE:pc-BASE+4] == bytes.fromhex(word) for pc, word in words.items())
        rows.append(row)
        all_words.append(words)
    assert rows[0] == rows[1] and all_words[0] == all_words[1]
    report = dict(schema='ys4470.native-cold-bss.v1', images=images, total_cases=2,
                  cases=rows, instruction_bytes={hex(pc):word for pc, word in sorted(all_words[0].items())},
                  source_sha256=sha(Path(__file__).read_bytes()),
                  limits=['Original DATA restoration reuses the existing original first-two-scatter-descriptor replay; third descriptor executes in a fresh ARM926 instance with that DATA.',
                          'Complete 0x7af808-byte BSS poison is zeroed; all other mapped bytes, including DATA and guards, remain unchanged. This is a cold RAM prerequisite, not complete GUI initialization.',
                          'No hardware bootstrap, initializer configuration hook, root constructors, registered callback firing or physical timing is executed or claimed.'])
    args.out.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(passed_cases=2, bss_bytes=LENGTH, instruction_words=len(all_words[0]), globals=rows[0]['globals'])))


if __name__ == '__main__':
    main()

"""Continue cold DATA/BSS-backed initialization through native configuration colors."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0
from validate_native_display_initializer_prefix import (
    InitializerPrefixReplay, GATE, STATE, OBJECT, HEAP, HEAP_BYTES, CONFIG_HOOK,
    AFTER_TIMER, TIMER, TIMER_LIST, TIMER_STATE, BASE, DRIVER, DISPLAY)
from validate_native_cold_bss import restore_globals, DATA, BSS, LENGTH

STYLE_ENTRY = 0x8005A334


class ColdConfigurationReplay(InitializerPrefixReplay):
    def __init__(self, raw):
        self.configuration_phase = False
        super().__init__(raw)
        self.u.mem_write(DATA, restore_globals(raw))
        # Exact effect of separately verified original third scatter descriptor.
        self.u.mem_write(BSS, bytes(LENGTH))
        self.configuration_calls = []

    def code(self, u, pc, size, data):
        if pc == self.stop:
            u.emu_stop()
            return
        if self.configuration_phase:
            if pc in (0x8003ADC4, 0x8003AD6C, 0x80025000):
                self.configuration_calls.append(hex(pc))
            if any(lo <= pc < hi for lo, hi in ((CONFIG_HOOK, 0x80058AF0),
                    (0x8003ADC4, 0x8003AE1C), (0x8003AD6C, 0x8003ADC0),
                    (0x80025000, 0x8002502C))):
                assert size == 4
                self.coverage[pc] = bytes(u.mem_read(pc, size)).hex()
                return
        super().code(u, pc, size, data)

    def write(self, u, access, address, size, value, data):
        if self.configuration_phase and STATE+2 <= address and address+size <= STATE+10:
            assert u.reg_read(UC_ARM_REG_PC) in (0x80058A6C, 0x80058A98, 0x80058AB8, 0x80058AE0)
            assert size == 2
            return
        super().write(u, access, address, size, value, data)

    def run_cold_configuration(self):
        assert self.word(GATE) == 0
        assert self.u.mem_read(STATE, 20) == bytes(20)
        assert self.u.mem_read(OBJECT, 36) == bytes(36)
        self.run_timer(0, 0)
        self.u.mem_write(HEAP-16, b'\x6E'*16)
        self.u.mem_write(HEAP, b'\xA5'*HEAP_BYTES)
        self.u.mem_write(HEAP+HEAP_BYTES, b'\xE6'*16)
        table = self.word(0x8003AE58)
        self.palette0 = struct.unpack('<H', self.u.mem_read(table, 2))[0]
        self.palette5 = struct.unpack('<H', self.u.mem_read(table+10, 2))[0]
        snapshots = {a: bytes(self.u.mem_read(a, n)) for a, n in
                     ((DRIVER, 80), (TIMER, 32), (TIMER_LIST, 12), (TIMER_STATE, 20))}
        expected_display = bytearray(self.u.mem_read(DISPLAY, 0x15C))
        expected_display[0x29] = 255
        struct.pack_into('<H', expected_display, 0x2A, 0xFFFF)
        self.timer_phase = False
        self.initializer_phase = True
        self.initializer_arguments = []
        self.initializer_heap_calls = self.resolution_calls = 0
        self.stop = CONFIG_HOOK
        self.u.emu_start(AFTER_TIMER, 0, count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC) == CONFIG_HOOK
        assert self.u.reg_read(UC_ARM_REG_LR) == 0x80040700
        assert self.initializer_heap_calls == 1 and self.resolution_calls == 2
        expected_object = bytearray(36)
        struct.pack_into('<I', expected_object, 0, self.word(0x80040738))
        struct.pack_into('<I', expected_object, 12, DISPLAY)
        struct.pack_into('<HH', expected_object, 16, self.palette5, self.palette0)
        struct.pack_into('<3I', expected_object, 20, *([0x80068B20]*3))
        expected_state = bytearray(20)
        expected_state[1] = 1
        struct.pack_into('<I', expected_state, 12, HEAP)
        assert self.u.mem_read(OBJECT, 36) == expected_object
        assert self.u.mem_read(STATE, 20) == expected_state
        # Independent palette table lookups; no inferred color units or format.
        table5, table4 = self.word(0x8003AE1C), self.word(0x8003ADC0)
        half = lambda address: struct.unpack('<H', self.u.mem_read(address, 2))[0]
        values = [half(table5 + (18*5+3)*2), half(table4 + (18*4+3)*2),
                  0xFFFF, half(table5 + (18*5+1)*2)]
        struct.pack_into('<4H', expected_state, 2, *values)
        self.configuration_phase = True
        self.stop = STYLE_ENTRY
        self.u.emu_start(CONFIG_HOOK, 0, count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC) == STYLE_ENTRY
        assert self.u.reg_read(UC_ARM_REG_LR) == 0x80058AF0
        assert self.u.reg_read(UC_ARM_REG_R0) == HEAP+0xD0
        assert self.configuration_calls == ['0x8003adc4', '0x8003ad6c', '0x80025000', '0x8003adc4']
        assert self.u.mem_read(STATE, 20) == expected_state
        assert self.u.mem_read(OBJECT, 36) == expected_object
        assert self.word(GATE) == HEAP
        assert self.u.mem_read(DISPLAY, 0x15C) == expected_display
        for address, snapshot in snapshots.items():
            assert self.u.mem_read(address, len(snapshot)) == snapshot
        assert self.u.mem_read(HEAP, HEAP_BYTES) == b'\xA5'*HEAP_BYTES
        assert self.u.mem_read(HEAP-16, 16) == b'\x6E'*16
        assert self.u.mem_read(HEAP+HEAP_BYTES, 16) == b'\xE6'*16
        return dict(cold_data_bss_applied_before_setup=True, palette_tables=[hex(table5), hex(table4)],
                    configuration_values=[hex(v) for v in values], state_hex=expected_state.hex(),
                    object_hex=expected_object.hex(), actual_native_helpers=self.configuration_calls,
                    state_byte0=0, heap_bytes=HEAP_BYTES, heap_untouched=True,
                    pending_style_argument=hex(HEAP+0xD0), stop_pc=hex(STYLE_ENTRY),
                    initializer_returned=False, driver_timer_display_checked=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[3]
    manifest = json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images, observations, originals = {}, [], []
    for item in manifest['images']:
        raw = (repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item['sha256'] and len(raw) == item['size_bytes']
        images[item['version']] = item['sha256']
        originals.append(raw)
        replay = ColdConfigurationReplay(raw)
        observations.append((replay.run_cold_configuration(), replay.coverage))
    assert observations[0] == observations[1]
    case, words = observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4] == bytes.fromhex(word) for raw in originals) for pc, word in words.items())
    report = dict(schema='ys4470.native-cold-configuration-prefix.v1', images=images,
                  total_cases=2, cases=[case], instruction_bytes={hex(pc):word for pc, word in sorted(words.items())},
                  source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                      (Path(__file__), Path(__file__).with_name('validate_native_cold_bss.py'),
                       Path(__file__).with_name('validate_native_display_initializer_prefix.py'))},
                  limits=['Original-restored DATA and separately verified BSS effect applied before setup; cold object retained holes are zero rather than poisoned.',
                          'Native configuration hook executes four original palette/default-value helpers; complete state/object and prior driver/timer/display references checked.',
                          'Stops before first style primitive0x8005a334: heap payload still A5, state byte0=0, initializer not returned. No full theme/root/callback/physical timing claim.',
                          'Existing hardware/context/display/timer heap/raw-clock/list-manager models persist;504-byte heap allocation modeled and guarded.'])
    args.out.write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(passed_cases=2, values=case['configuration_values'], stop=case['stop_pc'])))


if __name__ == '__main__':
    main()

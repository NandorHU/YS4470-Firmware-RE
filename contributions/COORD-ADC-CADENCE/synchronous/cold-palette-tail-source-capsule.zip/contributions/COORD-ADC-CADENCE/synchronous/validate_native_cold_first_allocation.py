"""Reach the first real style-growth allocation without replacing its outcome."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_SP
from validate_native_cold_inline_properties import InlineReplay, AFTER_TWO, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA

ALLOC = 0x80032800
COLOR_WRAPPER = 0x8003DC18


class FirstAllocationReplay(InlineReplay):
    def __init__(self, raw):
        self.growth_phase = False
        self.color_input = None
        self.next_property_input = None
        self.growth_zero_calls = []
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.growth_phase:
            if pc == self.stop:
                u.emu_stop()
                return
            if pc == COLOR_WRAPPER:
                self.color_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
                assert self.color_input[0] == HEAP+8
            if pc == 0x8003DFA0:
                self.next_property_input=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
            if pc == 0x80032E14:
                self.growth_zero_calls.append([u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)])
            if any(lo <= pc < hi for lo,hi in ((AFTER_TWO,0x80058BA8),(0x8005A334,0x8005A34C),
                    (0x8003D828,0x8003D830),(0x8003AE20,0x8003AE58),
                    (COLOR_WRAPPER,0x8003DC34),(0x8003DDE4,0x8003DFAC))):
                assert size == 4
                self.coverage[pc] = bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.growth_phase and HEAP+8 <= address and address+size <= HEAP+16:
            pc=u.reg_read(UC_ARM_REG_PC)
            assert 0x80032E14 <= pc < 0x80032EA4 or pc in (0x8003DF78,0x8003DDF0,0x8003DDF4,0x8003DF98)
            return
        super().write(u,access,address,size,value,data)

    def run_allocation_entry(self):
        self.run_inline()
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32))}
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        sp=self.u.reg_read(UC_ARM_REG_SP)
        self.inline_phase=False
        self.growth_phase=True
        self.stop=ALLOC
        self.u.emu_start(AFTER_TWO,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==ALLOC
        assert self.u.reg_read(UC_ARM_REG_R0)==12
        assert self.u.reg_read(UC_ARM_REG_LR)==0x8003DF24
        assert self.growth_zero_calls==[[HEAP+8,8,0x80058B60]]
        palette_table=self.word(0x8003AE58)
        palette18=struct.unpack('<H',self.u.mem_read(palette_table+18*2,2))[0]
        assert self.color_input[1]&0xFFFF==palette18
        # The original wrapper preserves incoming R2 high16 in its upper payload.
        # This retained halfword is opaque; no extra color channel is inferred.
        payload=palette18|(self.color_input[2]&0xFFFF0000)
        struct.pack_into('<IHBB',expected_heap,8,payload,0x20,0x04,1)
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        expected_next_value=self.word(0x800599FC)
        assert self.next_property_input==[HEAP+8,expected_next_value]
        assert self.u.reg_read(UC_ARM_REG_SP)==sp-32
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16
        assert self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected))==expected
        return dict(first_value_tag='0x20',first_palette_value=hex(palette18),
                    color_wrapper_input=[hex(v) for v in self.color_input],
                    opaque_retained_payload_halfword=hex((self.color_input[2]>>16)&0xFFFF),
                    first_inline_bytes=expected_heap[8:16].hex(),pending_tag='0xb',
                    pending_value=hex(expected_next_value),allocation_bytes=12,
                    allocator_return='0x8003df24',allocator_executed=False,
                    suspended_stack_bytes=32,complete_heap_reference=True,
                    bss_data_display_timer_guards_unchanged=True,stop_pc=hex(ALLOC),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=FirstAllocationReplay(raw);observations.append((replay.run_allocation_entry(),replay.coverage))
    assert observations[0]==observations[1]
    row,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-first-allocation.v1',images=images,total_cases=2,cases=[row],
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_inline_properties.py'))},
                limits=['Original cold style initialization and palette18/tag0x20 inline store execute. Complete504-byte heap matches independent byte reference; wrapper incoming R2 high16 is explicitly retained as opaque upper payload, not an inferred color channel.',
                        'Next original tag0xb differs from existing tag0x20, so native count1 branch requests12-byte allocation at0x80032800, LR0x8003df24. Allocator outcome is not replaced or executed; suspended32-byte frame is preserved.',
                        'Entire BSS/DATA, prior descriptors, display/timer and heap guards unchanged. No growth record, allocator success/failure, initializer return, roots/callback firing or physical timing is claimed.',
                        'Prior hardware/heap/raw-clock/list-manager and cold DATA/BSS effect models remain explicit.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=2,inline=row['first_inline_bytes'],allocation_bytes=12,pending_value=row['pending_value'])))


if __name__=='__main__':main()

"""Check null/moving-success realloc contracts before the next compound property."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_SP
from validate_native_cold_reallocation_entry import ReallocationEntryReplay, REALLOC, GROWTH, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA

MOVED = 0x11008000
FIRST_RETURN = 0x8003DD74


class ReallocationOutcomeReplay(ReallocationEntryReplay):
    def __init__(self,raw):
        self.reallocation_outcome_phase=False
        super().__init__(raw)

    def write(self,u,access,address,size,value,data):
        if self.reallocation_outcome_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+8 <= address and address+size <= HEAP+16:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if MOVED <= address and address+size <= MOVED+18:
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_reallocation_outcome(self,success):
        self.run_reallocation_entry()
        assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]==[GROWTH,18,0x8003DE90]
        suspended_sp=self.u.reg_read(UC_ARM_REG_SP)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),(GROWTH-16,44))}
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        prior=bytes(self.u.mem_read(GROWTH,12))
        initial_new=prior+b'\xA5'*6 if success else b'\xA5'*18
        self.u.mem_write(MOVED-16,b'\x7F'*16)
        self.u.mem_write(MOVED,initial_new)
        self.u.mem_write(MOVED+18,b'\xF7'*16)
        expected_new=initial_new
        if success:
            expected_new=struct.pack('<IIIHHH',0x9CF3,0x7FFF,6,0x20,0x0B,0x12)
            struct.pack_into('<IHBB',expected_heap,8,MOVED,0x20,0x07,3)
        self.reallocation_outcome_phase=True
        self.stop=FIRST_RETURN
        self.u.reg_write(UC_ARM_REG_R0,MOVED if success else 0)
        # Realloc result and successful prefix-copy are explicit allocator fixtures.
        self.u.emu_start(0x8003DE90,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==FIRST_RETURN
        assert self.u.reg_read(UC_ARM_REG_SP)==suspended_sp+32
        assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
        assert self.u.mem_read(MOVED,18)==expected_new
        assert self.u.mem_read(MOVED-16,16)==b'\x7F'*16
        assert self.u.mem_read(MOVED+18,16)==b'\xF7'*16
        assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16
        assert self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected))==expected
        return dict(reallocator_outcome_fixture='moving_success' if success else 'null',
                    modeled_prefix_copy_bytes=12 if success else 0,modeled_new_bytes=18,
                    modeled_return=hex(MOVED if success else 0),native_resume='0x8003de90',
                    style_hex=expected_heap[8:16].hex(),new_vector_hex=expected_new.hex(),
                    old_vector_and_guards_unchanged=True,complete_heap_bss_data_display_timer_checked=True,
                    all_new_guards_unchanged=True,property_stack_restored_bytes=32,
                    compound_frame_remaining_bytes=16,stop_pc=hex(FIRST_RETURN),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for success in (False,True):
            replay=ReallocationOutcomeReplay(raw)
            rows.append(replay.run_reallocation_outcome(success));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-reallocation-outcomes.v1',images=images,total_cases=4,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_reallocation_entry.py'))},
                limits=['Captured18-byte realloc is explicitly modeled as null or moving-success with only the old12-byte prefix copied and6-byte poisoned tail. Native allocator implementation and freeing/reuse are not executed.',
                        'Original3de90 continuation moves old tags, appends value6/tag12 and updates whole style to count3/summary07 on success. Null leaves prior style/vector unchanged. Complete18-byte target and504-byte heap independently checked.',
                        'Old12-byte allocation and guards are retained as fixtures; all new/heap guards, whole BSS/DATA/display/timer unchanged. Original property32-byte frame is restored, outer compound16-byte frame remains suspended at3dd74.',
                        'Remaining compound tags13/10/11, full configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=4,success_style=rows[1]['style_hex'],success_vector=rows[1]['new_vector_hex'],stop=rows[1]['stop_pc'])))


if __name__=='__main__':main()

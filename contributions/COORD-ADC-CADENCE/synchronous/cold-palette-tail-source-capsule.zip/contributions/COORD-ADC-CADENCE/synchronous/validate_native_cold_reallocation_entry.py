"""Execute native encoded-driver scaling and stop at first18-byte reallocation."""
import argparse
import hashlib
import json
from pathlib import Path

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_growth_outcomes import GrowthOutcomeReplay, GROWTH, AFTER_GROWTH, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE
from validate_native_cold_bss import BSS, LENGTH, DATA
from trace_display_refresh_setup import DRIVER

REALLOC = 0x80032AE4


class ReallocationEntryReplay(GrowthOutcomeReplay):
    def __init__(self, raw):
        self.reallocation_entry_phase = False
        self.scaling_calls, self.scaling_results, self.metric_results = [], [], []
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.reallocation_entry_phase:
            if pc == self.stop:
                u.emu_stop()
                return
            if pc == 0x80025958:
                args=[u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1)]
                assert args==[DISPLAY,7]
                self.scaling_calls.append(args)
            if pc == 0x800259AC:
                self.scaling_results.append(u.reg_read(UC_ARM_REG_R0))
            if pc == 0x80025CD0:
                self.metric_results.append(u.reg_read(UC_ARM_REG_R0))
            if any(lo <= pc < hi for lo,hi in ((AFTER_GROWTH,0x80058BC4),(0x80025958,0x800259B0),
                                               (0x80025CA4,0x80025CD4),(0x8003DD64,0x8003DE90))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def run_reallocation_entry(self):
        self.run_outcome(True)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (HEAP-16,HEAP_BYTES+32),(GROWTH-16,44))}
        sp=self.u.reg_read(UC_ARM_REG_SP)
        encoded=((self.word(DRIVER+0x10)<<15)&0xFFFFFFFF)>>22
        assert encoded==130 and encoded*7+80>=320
        multiplier=self.word(0x800259B0)
        assert multiplier==0x66666667
        expected_value=(encoded*7+80)//160
        assert expected_value==6
        self.reallocation_entry_phase=True
        self.stop=REALLOC
        self.u.emu_start(AFTER_GROWTH,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
        assert self.scaling_calls==[[DISPLAY,7]]
        assert self.metric_results==[encoded,encoded]
        assert self.scaling_results==[expected_value]
        assert [self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]==[GROWTH,18,0x8003DE90]
        assert self.u.reg_read(UC_ARM_REG_R8)==0x12
        assert self.u.reg_read(UC_ARM_REG_R9)==expected_value
        assert self.u.reg_read(UC_ARM_REG_SP)==sp-48
        for address,expected in snapshots.items():
            assert self.u.mem_read(address,len(expected))==expected
        return dict(native_scaling_call=[hex(DISPLAY),7],driver_flags=hex(self.word(DRIVER+0x10)),
                    encoded_driver_metric=encoded,native_result=expected_value,raw_division_reference='(130*7+80)//160',multiplier=hex(multiplier),
                    pending_tag='0x12',pending_value=expected_value,reallocation_old_pointer=hex(GROWTH),
                    reallocation_bytes=18,reallocation_return='0x8003de90',reallocator_executed=False,
                    suspended_stack_bytes=48,all_prior_buffers_and_guards_unchanged=True,
                    stop_pc=hex(REALLOC),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        replay=ReallocationEntryReplay(raw);observations.append((replay.run_reallocation_entry(),replay.coverage))
    assert observations[0]==observations[1]
    row,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-reallocation-entry.v1',images=images,total_cases=2,cases=[row],
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_growth_outcomes.py'))},
                limits=['Original25958(DISPLAY,7) reads encoded driver metric130 from flags413c and takes original multiply/divide path to result6. No resolution/DPI/physical-unit meaning is inferred.',
                        'Compound wrapper3dd64 enters first tag12/value6 insertion and original count2 lookup misses; native32ae4 receives existing12-byte vector and new18-byte size. Stops before reallocator executes or is modeled.',
                        'Whole prior BSS/DATA/display/timer/504-byte heap/12-byte vector and all guards unchanged;48-byte compound/property frames suspended. Remaining three compound properties have not executed.',
                        'Prior12-byte allocator success fixture and hardware/raw-clock/list-manager/cold DATA-BSS effect models persist; initializer return, roots/callbacks and physical timing remain open.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=2,encoded_metric=130,native_result=6,reallocation_bytes=18,pending_tag='0x12')))


if __name__=='__main__':main()

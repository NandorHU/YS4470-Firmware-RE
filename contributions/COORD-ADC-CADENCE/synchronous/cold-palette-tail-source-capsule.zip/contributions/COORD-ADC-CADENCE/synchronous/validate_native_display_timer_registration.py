"""Continue original display registration through native timer/list construction."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R6, UC_ARM_REG_R7, UC_ARM_REG_SP
from validate_native_driver_callback_origin import DriverOriginReplay, BASE, DRIVER, DISPLAY
from trace_display_refresh_setup import RETURN, STACK

TIMER_LIST,TIMER_STATE=0x807B531C,0x805ABDAC
TIMER,PREVIOUS=0x11004000,0x11005000
AFTER_TIMER=0x80025AE8


class DisplayTimerReplay(DriverOriginReplay):
    def __init__(self,raw):
        self.timer_phase=self.list_init_phase=False
        self.raw=raw
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.list_init_phase and 0x8000A9BC<=pc<0x8000A9D8:
            assert size==4
            self.coverage[pc]=bytes(u.mem_read(pc,size)).hex();return
        if self.timer_phase:
            if pc==0x80040894:
                args=[u.reg_read(reg) for reg in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2)]
                assert args==[self.callback,30,DISPLAY] and u.reg_read(UC_ARM_REG_LR)==0x80025AE0
                self.timer_arguments.append(args)
            if pc==0x80032800:
                assert u.reg_read(UC_ARM_REG_R0)==32 and u.reg_read(UC_ARM_REG_LR)==0x8000A9EC
                self.heap_calls+=1
                u.reg_write(UC_ARM_REG_R0,TIMER);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
            if pc==0x800407A0:
                assert u.reg_read(UC_ARM_REG_LR)==0x800408D0
                self.clock_calls+=1
                u.reg_write(UC_ARM_REG_R0,self.raw_clock);u.reg_write(UC_ARM_REG_PC,u.reg_read(UC_ARM_REG_LR));return
            if any(lo<=pc<hi for lo,hi in ((0x80025AC8,AFTER_TIMER),(0x80040894,0x800408F0),(0x8000A9D8,0x8000AA48))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex();return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        pc=u.reg_read(UC_ARM_REG_PC)
        if (self.list_init_phase or self.timer_phase) and TIMER_LIST<=address and address+size<=TIMER_LIST+12:
            assert 0x8000A9BC<=pc<0x8000AA48
            return
        if self.timer_phase and TIMER<=address and address+size<=TIMER+32:
            assert 0x8000A9D8<=pc<0x8000AA48 or 0x80040894<=pc<0x800408F0
            return
        if self.timer_phase and TIMER_STATE<=address and address+size<=TIMER_STATE+0x14:
            assert address==TIMER_STATE+4 and size==1 and value==1 and pc==0x800408E0
            return
        if self.timer_phase and address==0x805ABD60:
            assert size==4 and value==DISPLAY and pc==0x80025AD8
            return
        super().write(u,access,address,size,value,data)

    def run_timer(self,clock,previous):
        self.list_init_phase=True
        self.execute(0x8000A9BC,RETURN,((UC_ARM_REG_R0,TIMER_LIST),(UC_ARM_REG_R1,24)))
        self.list_init_phase=False
        assert [self.word(TIMER_LIST+off) for off in (0,4,8)]==[24,0,0]
        self.u.mem_write(TIMER-16,b'\x9B'*16)
        self.u.mem_write(TIMER,b'\xA5'*32)
        self.u.mem_write(TIMER+32,b'\xB9'*16)
        self.u.mem_write(TIMER_STATE,bytes(0x14))  # Explicit manager state fixture.
        origin=self.run_origin()
        self.callback=struct.unpack_from('<I',self.raw,0x80025C38-BASE)[0]
        assert self.callback==0x800094F8
        slot=self.u.reg_read(UC_ARM_REG_R7)+12
        assert slot==self.word(0x80025C34)+12==0x805ABD60
        self.put(slot,previous)
        driver=bytes(self.u.mem_read(DRIVER,80))
        expected_display=bytearray(self.u.mem_read(DISPLAY,0x15C))
        struct.pack_into('<I',expected_display,4,TIMER)
        sp=self.u.reg_read(UC_ARM_REG_SP)
        caller_frame=bytes(self.u.mem_read(sp,STACK-sp))
        self.raw_clock=clock;self.heap_calls=self.clock_calls=0;self.timer_arguments=[]
        self.timer_phase=True;self.stop=AFTER_TIMER
        self.u.emu_start(0x80025AC8,0,count=10000)
        assert self.u.reg_read(UC_ARM_REG_PC)==AFTER_TIMER
        assert self.u.reg_read(UC_ARM_REG_SP)==sp
        assert bytes(self.u.mem_read(sp,STACK-sp))==caller_frame
        assert self.u.reg_read(UC_ARM_REG_R6)==previous and self.word(slot)==DISPLAY
        assert (self.heap_calls,self.clock_calls)==(1,1)
        assert self.timer_arguments==[[self.callback,30,DISPLAY]]
        expected_timer=struct.pack('<8I',30,clock,self.callback,DISPLAY,0xFFFFFFFF,0,0,0)
        assert bytes(self.u.mem_read(TIMER,32))==expected_timer
        assert [self.word(TIMER_LIST+off) for off in (0,4,8)]==[24,TIMER,TIMER]
        assert self.u.mem_read(TIMER-16,16)==b'\x9B'*16 and self.u.mem_read(TIMER+32,16)==b'\xB9'*16
        expected_state=bytearray(0x14);expected_state[4]=1
        assert bytes(self.u.mem_read(TIMER_STATE,0x14))==expected_state
        assert bytes(self.u.mem_read(DISPLAY,0x15C))==expected_display
        assert bytes(self.u.mem_read(DRIVER,80))==driver and self.word(DRIVER+0x1C)==0
        return dict(raw_clock_fixture=clock,previous_display_pointer_fixture=hex(previous),
                    display_pointer_slot=hex(slot),registered_callback=hex(self.callback),raw_period=30,userdata=hex(DISPLAY),
                    native_timer_hex=expected_timer.hex(),timer_list_words=[24,hex(TIMER),hex(TIMER)],
                    modeled_heap_bytes=32,timer_allocation_guards_unchanged=True,caller_frame_unchanged=True,
                    native_driver_callback=origin['final_callback_word'],stop_pc=hex(AFTER_TIMER))


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path);args=parser.parse_args()
    manifest=json.loads(Path('original-firmware/manifest.json').read_bytes())
    images,originals,observed={},[],[]
    for item in manifest['images']:
        raw=Path(item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        cases,coverage=[],{}
        for clock,previous in ((0,0),(0xFFFFFFF0,PREVIOUS)):
            replay=DisplayTimerReplay(raw)
            cases.append(replay.run_timer(clock,previous));coverage.update(replay.coverage)
        observed.append((cases,coverage))
    assert observed[0]==observed[1]
    cases,coverage=observed[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in coverage.items())
    report=dict(schema='ys4470.native-display-timer-registration.v1',images=images,total_cases=len(cases)*2,cases=cases,
                instruction_bytes={hex(pc):word for pc,word in sorted(coverage.items())},
                source_sha256={name:hashlib.sha256(Path(__file__).with_name(name).read_bytes()).hexdigest() for name in (Path(__file__).name,'validate_native_driver_callback_origin.py')},
                limits=['Original poisoned-driver display setup continues in its actual stack frame through global display-pointer update and timer constructor0x80040894 to0x80025ae8.',
                        'Callback0x800094f8/period30/userdataDISPLAY come from original caller instructions/literal. Original list initializer/insertion and timer payload stores execute; complete32-byte node, links/header, display object, manager-state bytes and allocation guards match independent references.',
                        'Timer list is explicitly initialized with the original primitive and24-byte item size; manager bytes, previous display pointer and raw clock are fixtures. Only32-byte heap allocation and clock read are modeled; raw clock values do not establish physical units or cadence.',
                        'Prior hardware/display/context allocation models persist. Stops before registration conditional branch/clock/object tail. Callback execution, scheduler-driven refresh, full registration, later driver writers and physical LCD/timing remain open.'])
    args.out.write_bytes((json.dumps(report,indent=2)+'\n').encode());print(f"PASS {report['total_cases']} connected native display timer-registration cases")


if __name__=='__main__':main()

"""Execute tag21/raw66 and tag66/record insertions under all two-step outcomes."""
import argparse
import hashlib
import itertools
import json
from pathlib import Path
import struct

from unicorn.arm_const import UC_ARM_REG_PC, UC_ARM_REG_LR, UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R8, UC_ARM_REG_R9, UC_ARM_REG_SP
from validate_native_cold_tag1_growth import Tag1Replay, NEW, AFTER_TAG1, GROWTH, MOVED, HEAP, HEAP_BYTES, DISPLAY, TIMER, BASE, vector_bytes
from validate_native_cold_reallocation_entry import REALLOC
from validate_native_cold_bss import BSS, LENGTH, DATA

AFTER_RECORDS = 0x80058C00


class RecordPropertiesReplay(Tag1Replay):
    def __init__(self,raw):
        self.record_properties_phase=False
        self.record_buffers={}
        super().__init__(raw)

    def code(self,u,pc,size,data):
        if self.record_properties_phase:
            if pc==self.stop:
                u.emu_stop()
                return
            if any(lo<=pc<hi for lo,hi in ((AFTER_TAG1,AFTER_RECORDS),(0x8003DC68,0x8003DC74),(0x8003E068,0x8003E074))):
                assert size==4
                self.coverage[pc]=bytes(u.mem_read(pc,size)).hex()
                return
        super().code(u,pc,size,data)

    def write(self,u,access,address,size,value,data):
        if self.record_properties_phase:
            pc=u.reg_read(UC_ARM_REG_PC)
            if HEAP+8<=address and address+size<=HEAP+16:
                assert pc in (0x8003DE98,0x8003DED0,0x8003DF98)
                return
            if any(a<=address and address+size<=a+len(raw) for a,raw in self.record_buffers.items()):
                assert pc in (0x8003DEB8,0x8003DDF0,0x8003DDF4)
                return
        super().write(u,access,address,size,value,data)

    def run_record_properties(self,schedule):
        assert len(schedule)==2
        self.run_tag1(True)
        snapshots={a:bytes(self.u.mem_read(a,n)) for a,n in
                   ((BSS,LENGTH),(DATA,0x15E4),(DISPLAY,0x15C),(TIMER,32),
                    (GROWTH-16,44),(MOVED-16,50),(NEW-16,74))}
        for a,raw in self.compound_buffers.items():snapshots[a-16]=bytes(self.u.mem_read(a-16,len(raw)+32))
        expected_heap=bytearray(self.u.mem_read(HEAP,HEAP_BYTES))
        values,tags=[0x9CF3,0x7FFF,6,6,6,6,4],[0x20,0x0B,0x12,0x13,0x10,0x11,1]
        pointer,summary,start=NEW,7,AFTER_TAG1
        sp=self.u.reg_read(UC_ARM_REG_SP)
        record=self.word(0x800599F8)
        assert record==0x807B52E4
        steps=[]
        self.record_properties_phase=True
        for index,(tag,value,category_bit,success,return_pc) in enumerate(zip(
                (0x21,0x66),(0x66,record),(4,64),schedule,(0x80058BF0,AFTER_RECORDS))):
            self.stop=REALLOC
            self.u.emu_start(start,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==REALLOC
            size=(len(values)+1)*6
            args=[self.u.reg_read(r) for r in (UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_LR)]
            assert args==[pointer,size,0x8003DE90]
            assert self.u.reg_read(UC_ARM_REG_R8)==tag and self.u.reg_read(UC_ARM_REG_R9)==value
            assert self.u.mem_read(pointer,len(values)*6)==vector_bytes(values,tags)
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            target=0x1100D000+index*0x1000
            initial=vector_bytes(values,tags)+b'\xA5'*6 if success else b'\xA5'*size
            self.u.mem_write(target-16,b'\x7A'*16)
            self.u.mem_write(target,initial)
            self.u.mem_write(target+size,b'\xA7'*16)
            self.record_buffers[target]=initial
            if success:
                values.append(value);tags.append(tag);summary|=category_bit;pointer=target
                self.record_buffers[target]=vector_bytes(values,tags)
                struct.pack_into('<IHBB',expected_heap,8,pointer,0x20,summary,len(values))
            self.u.reg_write(UC_ARM_REG_R0,target if success else 0)
            self.stop=return_pc
            self.u.emu_start(0x8003DE90,0,count=10000)
            assert self.u.reg_read(UC_ARM_REG_PC)==return_pc
            assert self.u.reg_read(UC_ARM_REG_SP)==sp
            assert self.u.mem_read(HEAP,HEAP_BYTES)==expected_heap
            for a,expected in self.record_buffers.items():
                assert self.u.mem_read(a,len(expected))==expected
                assert self.u.mem_read(a-16,16)==b'\x7A'*16 and self.u.mem_read(a+len(expected),16)==b'\xA7'*16
            for a,expected in snapshots.items():assert self.u.mem_read(a,len(expected))==expected
            assert self.u.mem_read(HEAP-16,16)==b'\x6E'*16 and self.u.mem_read(HEAP+HEAP_BYTES,16)==b'\xE6'*16
            steps.append(dict(tag=hex(tag),value=hex(value),actual_requested_bytes=size,
                              outcome_fixture='moving_success' if success else 'null',style_hex=expected_heap[8:16].hex(),
                              vector_hex=vector_bytes(values,tags).hex()))
            start=return_pc
        return dict(realloc_success_fixtures=list(schedule),steps=steps,final_tags=[hex(t) for t in tags],
                    final_values=[hex(v) for v in values],final_summary=hex(summary),final_count=len(values),
                    final_style_hex=expected_heap[8:16].hex(),complete_vectors_heap_guards_checked=True,
                    bss_data_display_timer_and_old_vectors_unchanged=True,caller_stack_preserved=True,
                    stop_pc=hex(AFTER_RECORDS),initializer_returned=False)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args();repo=Path(__file__).resolve().parents[3]
    manifest=json.loads((repo/'original-firmware/manifest.json').read_bytes())
    images,originals,observations={},[],[]
    for item in manifest['images']:
        raw=(repo/item['path']).read_bytes()
        assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['size_bytes']
        images[item['version']]=item['sha256'];originals.append(raw)
        rows,words=[],{}
        for schedule in itertools.product((False,True),repeat=2):
            replay=RecordPropertiesReplay(raw);rows.append(replay.run_record_properties(schedule));words.update(replay.coverage)
        observations.append((rows,words))
    assert observations[0]==observations[1]
    rows,words=observations[0]
    assert all(all(raw[pc-BASE:pc-BASE+4]==bytes.fromhex(word) for raw in originals) for pc,word in words.items())
    report=dict(schema='ys4470.native-cold-record-properties.v1',images=images,total_cases=8,cases=rows,
                instruction_bytes={hex(pc):word for pc,word in sorted(words.items())},
                source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    (Path(__file__),Path(__file__).with_name('validate_native_cold_tag1_growth.py'))},
                limits=['Original3dc68/tag21/raw66 and3e068/tag66/record807b52e4 execute under all four null/moving-success realloc schedules. Each actual pointer/size is captured before modeled outcome; all-success requests48/54 bytes.',
                        'All complete vectors and504-byte heap independently checked after each native insertion; summary changes to47 only when tag66 succeeds. Every retained old/new buffer, guard, BSS/DATA/display/timer reference and caller SP checked.',
                        'Prefix-copy/poison-tail and allocator success/failure remain explicit fixtures; native freeing/reuse and physical meanings of raw properties are not inferred. Stored callback pointers are not invoked.',
                        'Stops58c00 before next style initialization. Remaining configuration/initializer return, roots/callbacks and physical timing remain open; prior hardware/raw-clock/list-manager models persist.'])
    args.out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(passed_cases=8,schedules=4,success_sizes=[x['actual_requested_bytes'] for x in rows[-1]['steps']],success_style=rows[-1]['final_style_hex'])))


if __name__=='__main__':main()
